<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\CustomerCredential;
use Illuminate\Support\Facades\DB;
use App\Traits\Auditable;

class Customer extends Authenticatable
{
    use HasApiTokens, Notifiable, Auditable;

    protected static ?string $auditModule = 'Customer';

    /**
     * Business Partner type. Satu master (`customer`) dipakai untuk dua jenis
     * mitra; data lama semuanya TYPE_CUSTOMER (lihat migration add_type_to_customer).
     */
    public const TYPE_CUSTOMER = 'Customer';
    public const TYPE_VENDOR   = 'Vendor';
    public const TYPES = [self::TYPE_CUSTOMER, self::TYPE_VENDOR];

    protected $table = 'customer';
    protected $primaryKey = 'customer_id';
    public $timestamps = true;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'customer_code',
        'type',
        'email',
        'domain',
        'is_active',
        'parent_customer_id',
        'customer_group_id',
    ];

    /**
     * The attributes that should be cast.
     */
    protected $casts = [
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'email_verified_at' => 'datetime',
    ];

    // ==================== AUTHENTICATION RELATIONSHIPS ====================

    /**
     * Customer has no role in the new schema.
     */

    /**
     * Get login activities for the customer
     * 
     * @return HasMany
     */
    public function loginActivities(): HasMany
    {
        return $this->hasMany(LoginActivity::class, 'user_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    // ==================== DATA MANAGEMENT RELATIONSHIPS ====================

    /**
     * Get the basic data for the customer (one-to-one)
     * 
     * @return HasOne
     */
    public function basicData(): HasOne
    {
        return $this->hasOne(CustomerBasicData::class, 'customer_id', 'customer_id');
    }

    /**
     * Get all addresses for the customer (one-to-many)
     * 
     * @return HasMany
     */
    public function addresses(): HasMany
    {
        return $this->hasMany(CustomerAddress::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Get the primary/home address
     * 
     * @return HasOne
     */
    public function primaryAddress(): HasOne
    {
        return $this->hasOne(CustomerAddress::class, 'customer_id', 'customer_id')
            ->where(function($query) {
                $query->where('address_type', 'Home')
                    ->orWhere('address_type', 'Primary');
            })
            ->orderBy('created_at', 'asc');
    }

    /**
     * Get the contact information for the customer (one-to-one)
     * 
     * @return HasOne
     */
    public function contact(): HasOne
    {
        return $this->hasOne(CustomerContact::class, 'customer_id', 'customer_id');
    }

    /**
     * All contact persons for this customer (supports multiple login accounts)
     */
    public function contacts()
    {
        return $this->hasMany(CustomerContact::class, 'customer_id', 'customer_id');
    }

    /**
     * Get all identifications for the customer (one-to-many)
     * 
     * @return HasMany
     */
    public function identifications(): HasMany
    {
        return $this->hasMany(CustomerIdentification::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Get all bank accounts for the customer (one-to-many)
     * 
     * @return HasMany
     */
    public function banks(): HasMany
    {
        return $this->hasMany(CustomerBank::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Get the primary/first bank account
     * 
     * @return HasOne
     */
    public function primaryBank(): HasOne
    {
        return $this->hasOne(CustomerBank::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'asc');
    }

    /**
     * Get the credential for the customer (one-to-one)
     *
     * @return HasOne
     */
    public function credential(): HasOne
    {
        return $this->hasOne(CustomerCredential::class, 'customer_id', 'customer_id');
    }

    /**
     * Get all attachments for the customer (one-to-many)
     *
     * @return HasMany
     */
    public function attachments(): HasMany
    {
        return $this->hasMany(CustomerAttachment::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    // ==================== HIERARCHY RELATIONSHIPS ====================

    public function parentCustomer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'parent_customer_id', 'customer_id');
    }

    public function endCustomers(): HasMany
    {
        return $this->hasMany(Customer::class, 'parent_customer_id', 'customer_id');
    }

    public function isEndCustomer(): bool
    {
        return $this->parent_customer_id !== null;
    }

    public function isParentCustomer(): bool
    {
        return $this->parent_customer_id === null;
    }

    /**
     * Customer Group struktural (grouping datar, anggota tetap mandiri).
     */
    public function group(): BelongsTo
    {
        return $this->belongsTo(CustomerGroup::class, 'customer_group_id', 'id');
    }

    /**
     * Mirror nama grup ke kolom teks lama `customer_basic_data.customer_group`
     * agar filter list, header card, dan API Jarvies yang membaca kolom teks
     * tetap berfungsi setelah grouping di-upgrade menjadi berbasis FK.
     *
     * Dipanggil dari controller setiap kali `customer_group_id` berubah.
     */
    public function syncGroupNameToBasicData(): void
    {
        $groupName = $this->customer_group_id
            ? optional(CustomerGroup::find($this->customer_group_id))->name
            : null;

        if ($this->basicData) {
            $this->basicData->update(['customer_group' => $groupName]);
        }
    }

    /**
     * Get all history records for the customer (one-to-many)
     * 
     * @return HasMany
     */
    public function history(): HasMany
    {
        return $this->hasMany(CustomerHistory::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Get recent history records (last 10)
     * 
     * @return HasMany
     */
    public function recentHistory(): HasMany
    {
        return $this->hasMany(CustomerHistory::class, 'customer_id', 'customer_id')
            ->orderBy('created_at', 'desc')
            ->limit(10);
    }

    // ==================== AUTHENTICATION METHODS ====================

    /**
     * Check if customer can login
     * 
     * @return bool
     */
    public function canLogin(): bool
    {
        if (!$this->is_active) {
            return false;
        }

        if ($this->basicData && ($this->basicData->block || $this->basicData->deletion_flag)) {
            return false;
        }

        return true;
    }

    /**
     * Record login activity
     * 
     * @param string $ipAddress
     * @param string $userAgent
     * @return LoginActivity
     */
    public function recordLogin(string $ipAddress, string $userAgent)
    {
        return $this->loginActivities()->create([
            'ip_address' => $ipAddress,
            'user_agent' => $userAgent,
            'login_at' => now(),
        ]);
    }

    // ==================== SCOPES ====================

    public function scopeTopLevel($query)
    {
        return $query->whereNull('parent_customer_id');
    }

    /**
     * Scope: Business Partner bertipe tertentu ('Customer' / 'Vendor').
     */
    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope: hanya business partner bertipe Customer (klien).
     */
    public function scopeCustomers($query)
    {
        return $query->where('type', self::TYPE_CUSTOMER);
    }

    /**
     * Scope: hanya business partner bertipe Vendor.
     */
    public function scopeVendors($query)
    {
        return $query->where('type', self::TYPE_VENDOR);
    }

    /**
     * Scope: Get active customers only (can login)
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true)
            ->whereHas('basicData', function($q) {
                $q->where('deletion_flag', false)
                  ->where('block', false);
            });
    }

    /**
     * Scope: Get customers with addresses
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeWithAddresses($query)
    {
        return $query->whereHas('addresses');
    }

    /**
     * Scope: Get customers with complete data
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeComplete($query)
    {
        return $query->whereHas('basicData')
            ->whereHas('contact')
            ->whereHas('addresses');
    }

    /**
     * Scope: Get customers by customer group
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $group
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByGroup($query, $group)
    {
        return $query->whereHas('basicData', function($q) use ($group) {
            $q->where('customer_group', $group);
        });
    }

    /**
     * Scope: Get customers by customer category
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $category
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByCategory($query, $category)
    {
        return $query->whereHas('basicData', function($q) use ($category) {
            $q->where('customer_category', $category);
        });
    }

    /**
     * Scope: Search customers by name, code, or email
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $search
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeSearch($query, $search)
    {
        return $query->where(function($q) use ($search) {
            $q->where('customer_code', 'like', '%' . $search . '%')
              ->orWhere('email', 'like', '%' . $search . '%')
              ->orWhereHas('basicData', function($subQ) use ($search) {
                  $subQ->where('name_1', 'like', '%' . $search . '%')
                       ->orWhere('name_2', 'like', '%' . $search . '%')
                       ->orWhere('search_term_1', 'like', '%' . $search . '%')
                       ->orWhere('search_term_2', 'like', '%' . $search . '%');
              });
        });
    }

    // ==================== ACCESSOR METHODS ====================

    /**
     * Get customer display name
     * 
     * @return string
     */
    public function getDisplayNameAttribute(): string
    {
        return $this->basicData->name_1 ?? $this->email ?? 'Unknown Customer';
    }

    /**
     * Get full address as string
     * 
     * @return string
     */
    public function getFullAddressAttribute(): string
    {
        $address = $this->primaryAddress;
        if (!$address) {
            return 'No address';
        }

        return implode(', ', array_filter([
            $address->street,
            $address->house_number ? 'No. ' . $address->house_number : null,
            $address->city,
            $address->postal_code,
            $address->country
        ]));
    }

    /**
     * Get customer status label
     * 
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        if (!$this->is_active) {
            return 'Inactive';
        }

        if (isset($this->basicData->deletion_flag) && $this->basicData->deletion_flag) {
            return 'Deleted';
        } elseif (isset($this->basicData->block) && $this->basicData->block) {
            return 'Blocked';
        }
        
        return 'Active';
    }

    /**
     * Get customer status color class
     * 
     * @return string
     */
    public function getStatusColorAttribute(): string
    {
        if (!$this->is_active) {
            return 'bg-gray-100 text-gray-800';
        }

        if (isset($this->basicData->deletion_flag) && $this->basicData->deletion_flag) {
            return 'bg-red-100 text-red-800';
        } elseif (isset($this->basicData->block) && $this->basicData->block) {
            return 'bg-orange-100 text-orange-800';
        }
        
        return 'bg-green-100 text-green-800';
    }

    // ==================== HELPER METHODS ====================

    /**
     * Normalize a domain string for storage / matching.
     * Lowercases, trims, and ensures leading "@" so stored form is always
     * "@example.co.id" regardless of how the user typed it. Empty/whitespace
     * input returns null so the column stays nullable.
     */
    public static function normalizeDomain(?string $raw): ?string
    {
        if ($raw === null) return null;
        $trimmed = trim(strtolower($raw));
        if ($trimmed === '') return null;
        return str_starts_with($trimmed, '@') ? $trimmed : '@' . $trimmed;
    }

    /**
     * Extract the domain portion (including "@") from an email address,
     * lowercased. Returns null if the input has no "@" or is empty.
     */
    public static function extractEmailDomain(?string $email): ?string
    {
        if (!$email) return null;
        $lower = strtolower(trim($email));
        $at    = strrpos($lower, '@');
        return $at === false ? null : substr($lower, $at);
    }

    /**
     * Konversi nama perusahaan ke kode inisial tepat 4 karakter.
     * Menggunakan pendekatan round-robin: ambil 1 karakter dari tiap kata per putaran
     * hingga terkumpul 4 karakter. Jika kurang, pad dengan 'X'.
     * Angka romawi (I–XV) → digit Arab.
     * Contoh:
     *   "Perum Jasa Tirta I"    → round-0: P,J,T,1      → "PJT1"
     *   "Bank Mandiri"          → round-0: B,M → round-1: A,A → "BMAA"
     *   "PT Telkom Indonesia"   → round-0: P,T,I → round-1: T → "PTIT"
     *   "Pertamina"             → round-0..3: P,E,R,T   → "PERT"
     *   "PT"                    → round-0: P,T → pad     → "PTXX"
     *
     * @param string $name
     * @return string  Selalu tepat 4 karakter
     */
    public static function companyNameToCode(string $name): string
    {
        if (empty(trim($name))) {
            return 'CUST';
        }

        // Peta Roman numeral — paling panjang dulu agar matching tepat
        $romanMap = [
            'XV'   => '15', 'XIV'  => '14', 'XIII' => '13', 'XII' => '12',
            'VIII' => '8',  'VII'  => '7',  'XI'   => '11', 'VI'  => '6',
            'IV'   => '4',  'IX'   => '9',  'III'  => '3',  'II'  => '2',
            'X'    => '10', 'V'    => '5',  'I'    => '1',
        ];

        $words = array_values(array_filter(
            preg_split('/[\s\-\.\/]+/', trim($name))
        ));

        // Bangun array karakter per kata
        $wordChars = [];
        foreach ($words as $word) {
            $upper = strtoupper($word);
            if (isset($romanMap[$upper])) {
                $wordChars[] = str_split($romanMap[$upper]);
            } elseif (ctype_digit($word)) {
                $wordChars[] = str_split($word);
            } else {
                $wordChars[] = str_split(strtoupper($word));
            }
        }

        // Round-robin: ambil 1 char dari tiap kata per putaran
        $code      = '';
        $charIndex = 0;
        while (strlen($code) < 4) {
            $foundAny = false;
            foreach ($wordChars as $chars) {
                if (isset($chars[$charIndex])) {
                    $code    .= $chars[$charIndex];
                    $foundAny = true;
                    if (strlen($code) >= 4) {
                        break;
                    }
                }
            }
            if (!$foundAny) {
                break;
            }
            $charIndex++;
        }

        // Pastikan tepat 4 karakter (pad 'X' jika kurang, potong jika lebih)
        return substr(str_pad($code, 4, 'X'), 0, 4);
    }

    /**
     * Generate unique customer_code dari inisial nama perusahaan.
     * Selalu menghasilkan tepat 4 karakter.
     * Jika base sudah ada, ganti karakter terakhir dengan counter (2-9, A-Z).
     * Contoh: "Perum Jasa Tirta I" → "PJT1"
     *         (jika sudah ada) → "PJT2", "PJT3", ...
     *
     * @param string $companyName
     * @return string  Selalu tepat 4 karakter
     */
    public static function generateCustomerCode(string $companyName = ''): string
    {
        $base = self::companyNameToCode($companyName); // selalu 4 char

        // Langsung pakai jika belum ada
        if (!self::where('customer_code', $base)->exists()) {
            return $base;
        }

        // Collision: ganti char terakhir dengan counter (2–9, A–Z)
        $prefix      = substr($base, 0, 3);
        $suffixChars = array_merge(range('2', '9'), range('A', 'Z'));
        foreach ($suffixChars as $char) {
            $code = $prefix . $char;
            if (!self::where('customer_code', $code)->exists()) {
                return $code;
            }
        }

        // Fallback ekstrem: 3 char prefix + digit waktu (mod 10)
        return $prefix . (string)(time() % 10);
    }

    /**
     * Check if customer has any addresses
     * 
     * @return bool
     */
    public function hasAddresses(): bool
    {
        return $this->addresses()->exists();
    }

    /**
     * Check if customer has contact information
     * 
     * @return bool
     */
    public function hasContact(): bool
    {
        return $this->contact()->exists();
    }

    /**
     * Check if customer has any identifications
     * 
     * @return bool
     */
    public function hasIdentifications(): bool
    {
        return $this->identifications()->exists();
    }

    /**
     * Check if customer has any bank accounts
     * 
     * @return bool
     */
    public function hasBanks(): bool
    {
        return $this->banks()->exists();
    }

    /**
     * Check if customer has any attachments
     * 
     * @return bool
     */
    public function hasAttachments(): bool
    {
        return $this->attachments()->exists();
    }

    /**
     * Get total count of all related records
     * 
     * @return array
     */
    public function getRelatedCounts(): array
    {
        return [
            'addresses' => $this->addresses()->count(),
            'identifications' => $this->identifications()->count(),
            'banks' => $this->banks()->count(),
            'attachments' => $this->attachments()->count(),
            'history' => $this->history()->count(),
            'login_activities' => $this->loginActivities()->count(),
        ];
    }

    /**
     * Log customer activity
     * 
     * @param string $action
     * @param string $description
     * @param string $section
     * @return CustomerHistory
     */
    public function logActivity(string $action, string $description, string $section = 'general')
    {
        return $this->history()->create([
            'action' => $action,
            'description' => $description,
            'section' => $section,
            'user_id' => session('user.id'),
            'user_name' => session('user.email') ?? session('user.name') ?? $this->email,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent()
        ]);
    }

    /**
     * Get customer summary data
     * 
     * @return array
     */
    public function getSummary(): array
    {
        return [
            'customer_id' => $this->customer_id,
            'customer_code' => $this->customer_code,
            'name' => $this->display_name,
            'email' => $this->email,
            'role' => 'Customer',
            'status' => $this->status_label,
            'can_login' => $this->canLogin(),
            'has_contact' => $this->hasContact(),
            'addresses_count' => $this->addresses()->count(),
            'identifications_count' => $this->identifications()->count(),
            'banks_count' => $this->banks()->count(),
            'attachments_count' => $this->attachments()->count(),
            'last_login' => $this->loginActivities()->latest()->first()?->login_at,
            'created_at' => $this->created_at->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * Get customer with all relationships loaded
     * 
     * @param int $customerId
     * @return Customer|null
     */
    public static function getWithAllRelations(int $customerId): ?Customer
    {
        return self::with([
            'basicData',
            'addresses',
            'contact',
            'identifications',
            'banks',
            'attachments',
            'recentHistory',
            'loginActivities' => function($query) {
                $query->limit(5);
            }
        ])->find($customerId);
    }

    /**
     * Create customer with basic data in transaction
     *
     * @param array $customerData (email, role_id)
     * @param array $basicData (name_1, customer_group, etc)
     * @return Customer
     * @throws \Exception
     */
    public static function createWithBasicData(array $customerData, array $basicData): Customer
    {
        return DB::transaction(function () use ($customerData, $basicData) {
            // Use provided customer_code or auto-generate from company name
            $customerCode = isset($customerData['customer_code']) && $customerData['customer_code'] !== ''
                ? strtoupper($customerData['customer_code'])
                : self::generateCustomerCode($basicData['name_1'] ?? '');

            // Create customer
            $customer = self::create([
                'customer_code' => $customerCode,
                'type' => $customerData['type'] ?? self::TYPE_CUSTOMER,
                'email' => $customerData['email'],
                'domain' => self::normalizeDomain($customerData['domain'] ?? null),
                'is_active' => $customerData['is_active'] ?? true,
                'parent_customer_id' => $customerData['parent_customer_id'] ?? null,
                'customer_group_id' => $customerData['customer_group_id'] ?? null,
            ]);

            // Create basic data (tanpa customer_code karena sudah pindah ke tabel customer)
            $customer->basicData()->create($basicData);

            // Log creation
            $customer->logActivity('create', 'Customer created', 'customer');

            return $customer->fresh(['basicData']);
        });
    }

    /**
     * Delete customer with all related data (soft delete through deletion_flag)
     * 
     * @return bool
     */
    public function softDeleteCustomer(): bool
    {
        return DB::transaction(function () {
            // Mark as deleted in basic data
            if ($this->basicData) {
                $this->basicData->update([
                    'deletion_flag' => true,
                    'last_changed_by' => session('user.email') ?? session('user.name') ?? 'system',
                    'last_changed_on' => now()
                ]);
            }

            // Mark customer as inactive (can't login)
            $this->update(['is_active' => false]);

            // Log deletion
            $this->logActivity('delete', 'Customer marked as deleted', 'customer');

            return true;
        });
    }

    /**
     * Restore deleted customer
     * 
     * @return bool
     */
    public function restoreCustomer(): bool
    {
        return DB::transaction(function () {
            // Restore in basic data
            if ($this->basicData) {
                $this->basicData->update([
                    'deletion_flag' => false,
                    'last_changed_by' => session('user.email') ?? session('user.name') ?? 'system',
                    'last_changed_on' => now()
                ]);
            }

            // Mark customer as active (can login)
            $this->update(['is_active' => true]);

            // Log restoration
            $this->logActivity('restore', 'Customer restored', 'customer');

            return true;
        });
    }

    /**
     * Hard delete customer with all related data
     * 
     * @return bool
     * @throws \Exception
     */
    public function hardDeleteCustomer(): bool
    {
        return DB::transaction(function () {
            // Delete all related data
            $this->addresses()->delete();
            $this->identifications()->delete();
            $this->banks()->delete();
            $this->history()->delete();
            $this->loginActivities()->delete();
            
            // Delete attachments and files
            foreach ($this->attachments as $attachment) {
                // Delete file from storage
                if ($attachment->file_path && \Storage::disk('public')->exists($attachment->file_path)) {
                    \Storage::disk('public')->delete($attachment->file_path);
                }
                $attachment->delete();
            }

            // Delete contact
            $this->contact()->delete();

            // Delete basic data
            $this->basicData()->delete();

            // Delete customer
            return $this->delete();
        });
    }

    // ==================== QUERY HELPERS ====================

    /**
     * Get paginated customers with basic data
     * 
     * @param int $perPage
     * @param array $filters
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public static function getPaginated(int $perPage = 15, array $filters = [])
    {
        $query = self::with(['basicData', 'parentCustomer.basicData', 'primaryAddress'])->withCount('endCustomers');

        // Apply filters
        if (!empty($filters['search'])) {
            $query->search($filters['search']);
        }

        // Filter `customer` (input "Search by email or company name") — frontend
        // mengirim key `customer`, jadi alias-kan ke scopeSearch yang sudah meng-cover
        // email + name_1 + name_2 + customer_code + search_term_*. Tetap pakai scope
        // yang sama supaya logic search konsisten.
        if (!empty($filters['customer'])) {
            $query->search($filters['customer']);
        }

        if (isset($filters['is_active'])) {
            $query->where('is_active', $filters['is_active']);
        }

        // Business Partner type ('Customer' / 'Vendor'). Kosong = tampilkan semua.
        if (!empty($filters['type']) && in_array($filters['type'], self::TYPES, true)) {
            $query->ofType($filters['type']);
        }

        // Filter status — derive dari kolom `block` & `deletion_flag` di
        // customer_basic_data (sumber yang sama dengan logika status di
        // CustomerController@getData baris 137-143).
        if (!empty($filters['status'])) {
            $status = $filters['status'];
            $query->whereHas('basicData', function ($q) use ($status) {
                if ($status === 'active') {
                    $q->where(function ($qq) {
                        $qq->where('block', false)->orWhereNull('block');
                    })->where(function ($qq) {
                        $qq->where('deletion_flag', false)->orWhereNull('deletion_flag');
                    });
                } elseif ($status === 'blocked') {
                    $q->where('block', true)
                      ->where(function ($qq) {
                          $qq->where('deletion_flag', false)->orWhereNull('deletion_flag');
                      });
                } elseif ($status === 'deleted') {
                    $q->where('deletion_flag', true);
                }
            });
        }

        // Customer Group: pakai LIKE (bukan exact match scopeByGroup) supaya
        // input bertahap "cor" → match "Corporate". Konsisten dengan UX text
        // search di frontend. byGroup scope tetap dipertahankan untuk caller
        // lain yang butuh exact match.
        if (!empty($filters['customer_group'])) {
            $term = $filters['customer_group'];
            $query->whereHas('basicData', function ($q) use ($term) {
                $q->where('customer_group', 'like', "%{$term}%");
            });
        }

        if (!empty($filters['customer_category'])) {
            $query->byCategory($filters['customer_category']);
        }

        if (!empty($filters['active_only']) && $filters['active_only']) {
            $query->active();
        }

        // Apply sorting
        $sortField = $filters['sort_field'] ?? 'created_at';
        $sortOrder = $filters['sort_order'] ?? 'desc';
        $query->orderBy($sortField, $sortOrder);

        return $query->paginate($perPage);
    }

    /**
     * Get customer statistics
     * 
     * @return array
     */
    public static function getStatistics(): array
    {
        return [
            'total' => self::count(),
            'active' => self::where('is_active', true)->count(),
            'inactive' => self::where('is_active', false)->count(),
            'can_login' => self::active()->count(),
            'with_addresses' => self::withAddresses()->count(),
            'with_contact' => self::whereHas('contact')->count(),
            'complete' => self::complete()->count(),
            'created_today' => self::whereDate('created_at', today())->count(),
            'created_this_week' => self::whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()])->count(),
            'created_this_month' => self::whereMonth('created_at', now()->month)->count(),
            'logged_in_today' => self::whereHas('loginActivities', function($q) {
                $q->whereDate('login_at', today());
            })->count(),
        ];
    }
}
