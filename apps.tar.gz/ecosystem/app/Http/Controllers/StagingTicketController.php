<?php

namespace App\Http\Controllers;

use App\Enums\RoleId;
use App\Models\AuditLog;
use App\Models\Customer;
use App\Models\CustomerCredential;
use App\Models\Employee;
use App\Models\StagingAttachment;
use App\Models\StagingTicket;
use App\Models\Ticket;
use App\Models\TicketMessage;
use App\Services\StagingTicketService;
use App\Support\SessionUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * StagingTicketController
 *
 * Endpoint yang dipakai:
 *   - Customer Project (Jarvies) → POST /api/staging-tickets    (submit tiket baru)
 *   - Employee/Admin (EcoSystem)  → GET  /api/staging-tickets    (list untuk validasi)
 *                                 → GET  /api/staging-tickets/{id}
 *                                 → POST /api/staging-tickets/{id}/approve
 *                                 → POST /api/staging-tickets/{id}/reject
 *   - Admin web view              → GET  /staging-tickets        (halaman validasi)
 */
class StagingTicketController extends Controller
{
    /**
     * Ambang "terlantar" untuk klaim ai_analysis_status='pending' — lihat
     * docblock analyze(). Margin di atas set_time_limit(630) (~10.5 menit)
     * yang dipasang di bawah untuk pemanggilan AI itu sendiri, supaya baris
     * yang MEMANG masih berjalan wajar tidak ikut ke-reclaim.
     */
    private const STALE_PENDING_MINUTES = 15;

    public function __construct(private StagingTicketService $service) {}

    // ─── Web view (admin) ─────────────────────────────────────────────────────

    /**
     * Halaman validasi staging ticket untuk admin/helpdesk.
     */
    public function view(Request $request)
    {
        $user = SessionUser::fromSession(session('user'));

        // Admin, Helpdesk, dan Head of Support yang boleh akses
        $allowed = array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value], RoleId::STAGING_GROUP);
        if (!$user || !$user->hasAnyRole($allowed)) {
            abort(403, 'Unauthorized');
        }

        $deliverySupports = \App\Models\DeliverySupport::orderBy('name')
            ->get(['id', 'client_id', 'name', 'type']);

        $deliverySupportsJson = $deliverySupports->map(fn($ds) => [
            'id'        => $ds->id,
            'client_id' => $ds->client_id,
            'name'      => $ds->name . ($ds->type ? ' (' . $ds->type . ')' : ''),
        ])->values();

        // Modul untuk dropdown Module di modal validasi. Sengaja dropdown, bukan
        // teks bebas: module_id inilah yang dipakai flow Power Automate untuk
        // menemukan Module Lead (nama modul yang diketik tangan tidak pernah cocok).
        $modules = \App\Models\Module::active()->orderBy('name')->get(['id', 'name'])->toArray();

        $ticketClassification = [
            'types' => \App\Support\TicketClassification::TYPES,
            'priorities' => \App\Support\TicketClassification::PRIORITIES,
            'scales' => \App\Support\TicketClassification::SCALES,
        ];

        // Untuk widget multi-select modul di modal approve (lihat approveModuleIds).
        $modules = \App\Models\Module::active()->orderBy('name')->get(['id', 'name']);

        return view('staging.index', compact('user', 'deliverySupports', 'deliverySupportsJson', 'ticketClassification', 'modules'));
    }

    /**
     * Rejected staging tickets page for admin/helpdesk/head-of-support.
     */
    public function viewRejected(Request $request)
    {
        $user = SessionUser::fromSession(session('user'));

        $allowed = array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value], RoleId::STAGING_GROUP);
        if (!$user || !$user->hasAnyRole($allowed)) {
            abort(403, 'Unauthorized');
        }

        return view('staging.rejected', compact('user'));
    }

    // ─── API: List staging tickets ────────────────────────────────────────────

    /**
     * GET /api/staging-tickets
     * Query params: status (unvalidated|approved|rejected), customer_id, per_page
     */
    public function index(Request $request)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            Log::warning('StagingTicketController@index: unauthorized — no session user', [
                'session_id' => session()->getId(),
                'ip'         => $request->ip(),
            ]);
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $roleId = $sessionUser['role']['id'] ?? null;

        Log::info('StagingTicketController@index: request received', [
            'user_id'     => $sessionUser['id'] ?? null,
            'role_id'     => $roleId,
            'filters'     => $request->only(['status', 'customer_id', 'per_page']),
            'session_id'  => session()->getId(),
            'ip'          => $request->ip(),
        ]);

        $isCustomerViewer = RoleId::EC_USER->value === $roleId;

        if (in_array($roleId, array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value, RoleId::EC_USER->value], RoleId::STAGING_GROUP), true)) {
            $query = StagingTicket::query();
        } else {
            Log::warning('StagingTicketController@index: forbidden — role not allowed', [
                'user_id' => $sessionUser['id'] ?? null,
                'role_id' => $roleId,
            ]);
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        // Filter
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        // Customer (EC_USER): SELALU dipaksa ke customer_id sesi sendiri, tidak
        // pernah percaya customer_id dari request — supaya satu akun customer
        // tidak bisa mengintip staging ticket customer lain sekadar dengan
        // mengganti/menghapus parameter query-nya. Staff internal boleh filter
        // customer_id manapun seperti biasa.
        if ($isCustomerViewer) {
            $query->where('customer_id', (int) $sessionUser['id']);
        } elseif ($request->filled('customer_id')) {
            $query->where('customer_id', $request->customer_id);
        }

        $query->with(['customer.basicData', 'endCustomer.basicData', 'validator.basicData', 'ticket'])
              ->orderBy('created_at', 'desc');

        $perPage = max(1, min((int) $request->get('per_page', 200), 500));

        try {
            $data = $query->paginate($perPage);
        } catch (\Exception $e) {
            Log::error('StagingTicketController@index: query failed', [
                'error'   => $e->getMessage(),
                'user_id' => $sessionUser['id'] ?? null,
            ]);
            return response()->json(['success' => false, 'message' => 'Failed to retrieve staging tickets. A database error occurred.'], 500);
        }

        Log::info('StagingTicketController@index: success', [
            'total'   => $data->total(),
            'per_page' => $data->perPage(),
            'user_id' => $sessionUser['id'] ?? null,
        ]);

        // Gerbang credential/ai_analysis TIDAK perlu dihitung di sini — list ini
        // dipanggil dengan includeHeavyFields: false, jadi ai_analysis tidak
        // pernah ikut terkirim untuk baris manapun (lihat formatStaging()).
        // Menghitungnya di sini hanya akan jadi query CustomerCredential yang
        // sia-sia, tidak pernah dipakai hasilnya.
        return response()->json([
            'success' => true,
            'data'    => $data->map(fn ($s) => $this->formatStaging($s, $isCustomerViewer, includeHeavyFields: false)),
            'meta'    => [
                'total'        => $data->total(),
                'per_page'     => $data->perPage(),
                'current_page' => $data->currentPage(),
                'last_page'    => $data->lastPage(),
            ],
        ]);
    }

    // ─── API: Show single ─────────────────────────────────────────────────────

    public function show($id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        // Sama seperti index(): role harus salah satu yang boleh melihat staging
        // ticket sama sekali. Dulu endpoint ini TIDAK punya gerbang role apa pun
        // (cuma cek login) — siapa pun yang sudah login (termasuk akun customer
        // lain) bisa membaca detail staging ticket manapun lewat ID sekadar
        // dengan menebak angka di URL.
        $roleId = $sessionUser['role']['id'] ?? null;
        $isCustomerViewer = RoleId::EC_USER->value === $roleId;
        $allowedRoles = array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value, RoleId::EC_USER->value], RoleId::STAGING_GROUP);
        if (!in_array($roleId, $allowedRoles, true)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $staging = StagingTicket::with(['customer.basicData', 'endCustomer.basicData', 'validator.basicData', 'ticket', 'attachments'])
                ->findOrFail($id);

            // Customer hanya boleh lihat staging ticket miliknya sendiri —
            // tanpa ini, EC_USER yang tahu/menebak ID staging ticket customer
            // lain bisa membaca seluruh detailnya (email, body, attachment).
            if ($isCustomerViewer && (int) $staging->customer_id !== (int) $sessionUser['id']) {
                return response()->json(['success' => false, 'message' => 'Staging ticket not found.'], 404);
            }

            $hasCredentialPermission = false;
            $customerIdsWithCredentials = [];
            if (!$isCustomerViewer && $staging->customer_id) {
                $hasCredentialPermission = (bool) Employee::find($sessionUser['id'] ?? null)?->hasMenuPermission('customer.section.credential.view');
                if (!$hasCredentialPermission && CustomerCredential::where('customer_id', $staging->customer_id)->exists()) {
                    $customerIdsWithCredentials = [$staging->customer_id];
                }
            }

            return response()->json([
                'success' => true,
                'data'    => $this->formatStaging($staging, $isCustomerViewer, $hasCredentialPermission, $customerIdsWithCredentials),
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['success' => false, 'message' => 'Staging ticket not found.'], 404);
        } catch (\Throwable $e) {
            Log::error('StagingTicketController@show: failed', [
                'id'    => $id,
                'error' => $e->getMessage(),
                'file'  => $e->getFile() . ':' . $e->getLine(),
            ]);
            return response()->json(['success' => false, 'message' => 'Failed to load staging ticket details.'], 500);
        }
    }

    // ─── API: Customer submit (dari Jarvies) ──────────────────────────────────

    /**
     * POST /api/staging-tickets
     * Dipanggil oleh Customer Project (Jarvies) saat customer submit tiket.
     */
    public function store(Request $request)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $validated = $request->validate([
            'description'          => 'required|string|max:5000',
            'body'                 => 'nullable|string',               // Isi tiket dari Jarvies (form body)
            'ticket_priority'      => 'required|in:Very High,High,Medium,Low',
            'sender_name'          => 'nullable|string|max:255',
            'submitted_by_email'   => 'nullable|email|max:255',        // Email login customer
            'cc_emails'            => 'nullable|string',               // JSON string: ["a@x.com","b@y.com"]
            'internet_message_id'  => 'nullable|string|max:1000',     // internetMessageId email [Menunggu Validasi] dari Jarvies
            // Field tambahan (opsional)
            'name'                 => 'nullable|string|max:255',       // Nama contact person
            'no_hp'                => 'nullable|string|max:255',       // Nomor HP
            'module'               => 'nullable|string|max:255',       // Modul terkait
            'client'               => 'nullable|string|max:255',       // Nama client
            'contact_id'           => 'nullable|integer',
        ]);

        try {
            $staging = $this->service->createFromWeb($validated, $sessionUser['id']);

            return response()->json([
                'success' => true,
                'message' => 'Your ticket has been submitted and is awaiting admin validation.',
                'data'    => $this->formatStaging($staging),
            ], 201);
        } catch (\Exception $e) {
            Log::error('StagingTicketController@store: gagal simpan staging', [
                'error' => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Failed to submit ticket',
            ], 500);
        }
    }

    // ─── API: JARVIES external submit (via X-Api-Key, tanpa session) ─────────

    /**
     * POST /jarvies/staging-tickets
     * Dipanggil oleh JARVIES saat customer submit tiket dari portal mereka.
     * Autentikasi via X-Api-Key middleware (bukan session).
     * customer_id diambil dari payload, bukan dari session.
     */
    public function jarviesStore(Request $request)
    {
        $validated = $request->validate([
            'description'          => 'required|string|max:5000',
            'body'                 => 'nullable|string',
            'ticket_priority'      => 'nullable|in:Very High,High,Medium,Low',
            'ticket_type'          => 'nullable|string|in:Incident,Change Request,Service Request,EWA,RISE,Consult',
            'sender_name'          => 'nullable|string|max:255',
            'submitted_by_email'   => 'nullable|email|max:255',
            'cc_emails'            => 'nullable|string',    // JSON string dari JARVIES
            'customer_id'          => 'required|integer',
            'end_customer_id'      => 'nullable|integer',
            'contact_id'           => 'nullable|integer',
            'name'                 => 'nullable|string|max:255',
            'no_hp'                => 'nullable|string|max:255',
            'module'               => 'nullable|string|max:255',
            'client'               => 'nullable|string|max:255',
            // Jika Jarvies sudah kirim email sendiri, kirim internet_message_id-nya
            // agar EcoSystem bisa link staging ke email tersebut (ambil graph_message_id + body)
            'internet_message_id'  => 'nullable|string|max:1000',
            'scale'                => 'nullable|string|max:50',
        ]);

        try {
            // Decode cc_emails jika dikirim sebagai JSON string
            if (isset($validated['cc_emails']) && is_string($validated['cc_emails'])) {
                $decoded = json_decode($validated['cc_emails'], true);
                if (is_array($decoded)) {
                    $validated['cc_emails'] = $decoded;
                }
            }

            $staging = $this->service->createFromWeb($validated, (int) $validated['customer_id']);

            Log::info('StagingTicketController@jarviesStore: staging created from JARVIES', [
                'staging_id'   => $staging->id,
                'customer_id'  => $validated['customer_id'],
                'ticket_type'  => $validated['ticket_type'] ?? null,
                'scale'        => $validated['scale'] ?? null,
                'scale_saved'  => $staging->scale,
            ]);

            // ── Link ke email Jarvies (jika internet_message_id dikirim) ─────────
            // Jika Jarvies kirim internet_message_id → langsung link ke email tersebut.
            // Jika tidak → biarkan processSentItems() menemukannya saat Fetch Email berikutnya.
            // EcoSystem TIDAK lagi kirim email duplikat karena Jarvies sudah kirim sendiri.
            $internetMsgId = $validated['internet_message_id'] ?? null;
            if ($internetMsgId) {
                $this->linkStagingToEmail($staging, $internetMsgId);
            }

            return response()->json([
                'success' => true,
                'id'      => $staging->id,
                'message' => 'Staging ticket created successfully',
            ], 201);

        } catch (\Exception $e) {
            Log::error('StagingTicketController@jarviesStore: gagal simpan staging', [
                'error' => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Failed to submit ticket',
            ], 500);
        }
    }

    // ─── API: Admin approve ───────────────────────────────────────────────────

    /**
     * POST /api/staging-tickets/{id}/approve
     * Admin menyetujui staging → dibuat ticket resmi.
     */
    public function approve(Request $request, $id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $roleId = $sessionUser['role']['id'];
        if (!in_array($roleId, array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value], RoleId::STAGING_GROUP), true)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        // Select kosong ("-- none --") dikirim sebagai string kosong; jadikan null
        // supaya lolos rule nullable|exists dan bisa dipakai mengosongkan modul.
        if ($request->input('module_id') === '') {
            $request->merge(['module_id' => null]);
        }

        $request->validate([
            'ticket_type'         => 'required|string|in:' . implode(',', \App\Support\TicketClassification::TYPES),
            'ticket_priority'     => 'required|string|in:' . implode(',', \App\Support\TicketClassification::PRIORITIES),
            'scale'               => 'nullable|string|in:' . implode(',', \App\Support\TicketClassification::SCALES),
            'name'                => 'nullable|string|max:255',
            'no_hp'               => 'nullable|string|max:255',
            'module'              => 'nullable|string|max:255',
            'module_ids'          => 'nullable|array',
            'module_ids.*'        => 'integer|exists:modules,id',
            'module_id'           => 'nullable|exists:modules,id',
            'client'              => 'nullable|string|max:255',
            'delivery_support_id' => 'nullable|exists:delivery_support,id',
            'end_customer_id'     => 'nullable|integer|exists:customer,customer_id',
        ]);

        $staging = StagingTicket::findOrFail($id);

        // Approve HANYA boleh kalau AI Analyzer sudah selesai — bukan cuma
        // preferensi UI, ini prasyarat keras: room AI Research BERSAMA yang
        // dibuat di bawah (createSharedAiResearchRoom()) di-seed dari hasil
        // analisa ini, jadi tanpa analisa yang selesai tidak ada apa pun yang
        // bisa di-seed. Tidak ada jalur manual untuk melewati ini — validator
        // harus menunggu/mencoba ulang (tombol Re-analyze) sampai berhasil.
        if ('completed' !== $staging->ai_analysis_status || !$staging->ai_analysis) {
            return response()->json([
                'success' => false,
                'message' => 'AI analysis must complete successfully before this ticket can be approved. Please wait for the analysis to finish, or click Re-analyze if it failed.',
            ], 422);
        }

        // Delivery support wajib dipilih SELAMA customer tiket ini memang punya
        // delivery support terdaftar (kalau tidak punya, field boleh kosong).
        // Yang dipilih juga harus benar-benar milik customer tersebut.
        if ($staging->customer_id) {
            $customerSupportIds = DB::table('delivery_support')
                ->where('client_id', $staging->customer_id)
                ->pluck('id')
                ->all();

            if (!empty($customerSupportIds)) {
                $chosenSupportId = (int) $request->input('delivery_support_id');
                if (!in_array($chosenSupportId, array_map('intval', $customerSupportIds), true)) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Delivery support is required and must belong to this customer.',
                        'errors'  => ['delivery_support_id' => ['Delivery support is required for this customer.']],
                    ], 422);
                }
            }
        }

        // Override additional info fields jika dikirim dari modal (nilai bisa berbeda
        // dari yang ada di staging, misal helpdesk menambahkan info saat validasi).
        foreach (['name', 'no_hp', 'module', 'module_id', 'client'] as $field) {
            if ($request->has($field)) {
                $staging->$field = $request->input($field);
            }
        }

        // "For customer" — saat tiket masuk via email & ter-route ke parent customer
        // (lewat domain), helpdesk dapat memilih end-customer (anak) tujuan tiket.
        // Hanya terima child yang benar-benar milik parent ini agar tidak salah assign.
        if ($request->has('end_customer_id')) {
            $endCustomerId = $request->input('end_customer_id') ?: null;
            if ($endCustomerId) {
                $isValidChild = Customer::where('customer_id', $endCustomerId)
                    ->where('parent_customer_id', $staging->customer_id)
                    ->exists();
                $staging->end_customer_id = $isValidChild ? $endCustomerId : null;
            } else {
                $staging->end_customer_id = null;
            }
        }
        $staging->save();

        try {
            $ticketType     = $request->input('ticket_type');
            $ticketPriority = $request->input('ticket_priority');
            $scale          = $request->input('scale');
            $moduleIds      = $request->input('module_ids', []);
            $result         = $this->service->approve($staging, $sessionUser['id'], $ticketType, $ticketPriority, $scale, $moduleIds);
            $ticket       = $result['ticket'];
            $firstMessage = $result['first_message'];

            // Jika staging dari email dan punya attachment → proses via Graph sekarang.
            // Cek has_attachments flag ATAU ada cid: di body (beberapa email client salah lapor).
            $hasCidInBody = str_contains($staging->email_body_html ?? '', 'cid:');
            if ($firstMessage && ($staging->has_attachments || $hasCidInBody) && $staging->graph_message_id) {
                try {
                    app(\App\Http\Controllers\EmailController::class)
                        ->processAttachmentsForMessage(
                            $staging->graph_message_id,
                            $firstMessage,
                            $ticket->ticket_id
                        );
                } catch (\Exception $e) {
                    // Attachment gagal tidak membatalkan approve — ticket sudah dibuat
                    Log::warning('StagingTicketController@approve: gagal proses attachment email', [
                        'staging_id' => $staging->id,
                        'error'      => $e->getMessage(),
                    ]);
                }
            }

            // Assign ticket to delivery support if selected at validation time
            if ($request->filled('delivery_support_id')) {
                $this->assignTicketToDeliverySupport($ticket, (int) $request->delivery_support_id);
            }

            // Kirim notifikasi balasan otomatis ke customer
            $this->sendApprovalNotification($staging, $ticket, $sessionUser, $firstMessage);

            // Sync ke JARVIES DB (staging update + ticket upsert)
            $this->syncApprovalToJarvies($staging, $ticket);

            // Notifikasi bell Jarvies — ticket berhasil dibuat
            if ($staging->customer_id) {
                \App\Services\CustomerNotificationService::notify(
                    customerId: (int) $staging->customer_id,
                    type:       'ticket_assigned',
                    ticketId:   (int) $ticket->ticket_id,
                    fromName:   'Helpdesk Support',
                    preview:    'Your ticket request has been validated. Ticket #' . $ticket->ticket_number . ' is now open.',
                    link:       '/tickets/' . $ticket->ticket_id,
                );
            }

            // Microsoft Teams lewat Power Automate: kartu tiket ke channel tim +
            // chat pribadi ke lead modul. Dikirim setelah response supaya validator
            // tidak menunggu Power Automate, dan kegagalannya tidak pernah
            // membatalkan approve yang sudah tersimpan.
            $this->notifyTeamsTicketValidated($ticket, $sessionUser);

            // Room AI Research BERSAMA — dibuat SEKARANG (bukan saat tombol
            // "Ask AI Research" diklik) supaya semua anggota tim tiket
            // langsung dapat konteks hasil AI Analyzer, bukan ringkasan
            // generik. Gagal di sini TIDAK boleh membatalkan approve yang
            // sudah tersimpan — sama seperti side-effect lain di atas.
            $this->createSharedAiResearchRoom($ticket, $staging, (int) $sessionUser['id']);

            return response()->json([
                'success' => true,
                'message' => 'Ticket validated and created successfully.',
                'data'    => [
                    'staging_id'       => $staging->id,
                    'ticket_id'        => $ticket->ticket_id,
                    'ticket_number'    => $ticket->ticket_number,
                    'first_message_id' => $firstMessage?->id,
                ],
            ]);
        } catch (\LogicException $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        } catch (\Exception $e) {
            Log::error('StagingTicketController@approve: failed to approve', [
                'staging_id' => $id,
                'error'      => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Failed to validate ticket',
            ], 500);
        }
    }

    /**
     * Kirim event "tiket divalidasi" ke Power Automate.
     *
     * Payload sudah memuat daftar lead modul beserta email kerjanya, jadi flow di
     * Power Automate cukup melakukan dua hal (post kartu ke channel, kirim chat
     * ke tiap lead) tanpa perlu menebak siapa penerimanya — pemetaan modul ->
     * lead adalah pengetahuan EcoSystem, bukan pengetahuan flow.
     *
     * Tiket yang modulnya belum punya lead tetap dikirim: kartunya masih berguna
     * di channel tim, dan flow bisa memilih melewati bagian chat pribadi dengan
     * memeriksa `lead_emails` yang kosong.
     */
    private function notifyTeamsTicketValidated(Ticket $ticket, array $sessionUser): void
    {
        try {
            $powerAutomate = app(\App\Services\PowerAutomateService::class);

            if (!$powerAutomate->isFlowReady(\App\Services\PowerAutomateService::FLOW_TICKET_VALIDATED)) {
                return;
            }

            $payloadTicket = $powerAutomate->ticketPayload($ticket);
            $leads         = $powerAutomate->moduleLeads($payloadTicket['module_id'], $payloadTicket['module']);

            $leadEmails    = $powerAutomate->leadEmails($leads);

            $chatPayload = $powerAutomate->ticketChatPayload(
                $payloadTicket,
                $leadEmails,
                $sessionUser['email'] ?? null
            );

            // Group chat dibuat EcoSystem sendiri lewat Graph, bukan oleh flow 5.
            // Gunanya kita MEMEGANG chat_id: tanpa itu, sinkronisasi pesan masuk
            // mustahil dan flow 6 terpaksa mencari chatnya lagi dengan mencocokkan
            // nama grup. Lihat docs/teams-chat-sync-design.md §4.
            //
            // try/catch sendiri, terpisah dari dispatch di bawah: Teams yang
            // bermasalah tidak boleh ikut membatalkan notifikasi Power Automate
            // yang selama ini sudah jalan.
            try {
                $teamsChat = app(\App\Services\Teams\TeamsChatService::class)->createForTicket(
                    (int) $ticket->ticket_id,
                    $chatPayload['topic'],
                    $chatPayload['members']
                );

                if ($teamsChat) {
                    $chatPayload['id'] = $teamsChat->chat_id;

                    // Penanda untuk flow 5: chatnya SUDAH ada, jangan bikin lagi.
                    // Tanpa Condition atas flag ini di sisi Power Automate, satu
                    // tiket akan punya DUA grup — satu dari sini, satu dari flow.
                    $chatPayload['created_by_ecosystem'] = true;
                }
            } catch (\Throwable $e) {
                Log::warning('StagingTicketController@approve: gagal membuat group chat Teams lewat Graph (non-fatal)', [
                    'ticket_id' => $ticket->ticket_id,
                    'error'     => $e->getMessage(),
                ]);
            }

            $powerAutomate->dispatchAfterResponse(
                \App\Services\PowerAutomateService::FLOW_TICKET_VALIDATED,
                [
                    'ticket'       => $payloadTicket,
                    'module_leads' => $leads,
                    'lead_emails'  => $leadEmails,
                    // Bahan group chat tiket (aksi Teams "Create a chat"):
                    // `chat.topic` jadi nama grup sekaligus kunci yang dipakai
                    // flow "ticket member added" untuk menemukan grup ini lagi
                    // lewat aksi "List chats". `chat.members_csv` berisi lead
                    // modul PLUS tim Delivery Support tiket ini (Delivery Owner,
                    // Support Manager, CO PM, Support Admin) PLUS pemegang role
                    // penjaga (Delivery Support Head dan Delivery Support
                    // Service Helpdesk).
                    'chat'         => $chatPayload,
                    // Identitas delivery support tiket + timnya, untuk baris
                    // "Delivery Support" di Adaptive Card. Emailnya sendiri
                    // sudah ikut lewat chat.members_csv di atas.
                    'delivery_support' => $powerAutomate->deliverySupportPayload(
                        (int) $ticket->ticket_id
                    ),
                    'validated_by' => [
                        'id'    => $sessionUser['id'] ?? null,
                        'name'  => $sessionUser['name'] ?? null,
                        'email' => $sessionUser['email'] ?? null,
                    ],
                ]
            );
        } catch (\Throwable $e) {
            Log::warning('StagingTicketController@approve: gagal menyiapkan notifikasi Teams (non-fatal)', [
                'ticket_id' => $ticket->ticket_id,
                'error'     => $e->getMessage(),
            ]);
        }
    }

    /**
     * Room AI Research BERSAMA untuk tiket ini — bisa diakses (baca+tulis)
     * oleh SEMUA anggota tim tiket (lead + member aktif, lihat
     * TicketTeamAccess::canAccessAiResearch()), bukan privat per-employee
     * seperti jalur PALING lama (sebelum room bersama ada sama sekali).
     * AiResearchController::openForTicket() SEKARANG JUGA membuat room
     * bersama yang sama bentuknya (bukan privat) — bedanya cuma pemicunya:
     * di sini dipicu approve(), di sana dipicu klik tombol untuk tiket yang
     * approve()-nya terjadi sebelum method ini ada.
     *
     * conversation_id pakai pola BARU ("ticket-team-{id}") — beda dari pola
     * lama ("ticket-{id}") yang dulu dipakai room privat — supaya TIDAK
     * PERNAH bentrok dengan unique constraint (employee_id, assistant,
     * conversation_id) milik room privat lama; tidak perlu ubah constraint
     * itu sama sekali. employee_id di baris ini cuma metadata "siapa yang
     * approve", BUKAN penentu akses — lihat AiResearchController::
     * resolveConversation().
     *
     * approve() sudah menggerbang: method ini TIDAK dipanggil kalau
     * ai_analysis belum completed (lihat pengecekan di awal approve()),
     * jadi $staging->ai_analysis selalu ada di sini.
     */
    private function createSharedAiResearchRoom(Ticket $ticket, StagingTicket $staging, int $validatedBy): void
    {
        try {
            $conversationId = "ticket-team-{$ticket->ticket_id}";

            $conversation = \App\Models\AiConversation::create([
                'employee_id'     => $validatedBy,
                'ticket_id'       => $ticket->ticket_id,
                'assistant'       => \App\Models\AiConversation::ASSISTANT_RESEARCH,
                'conversation_id' => $conversationId,
                'title'           => \Illuminate\Support\Str::limit(
                    trim($ticket->ticket_number . ' - ' . (string) $ticket->description),
                    180,
                    ''
                ),
            ]);

            $conversation->messages()->create([
                'role'    => 'user',
                'content' => \App\Support\TicketAnalysisSeed::build($ticket, (array) $staging->ai_analysis),
            ]);
        } catch (\Throwable $e) {
            Log::warning('StagingTicketController@approve: gagal membuat room AI Research bersama (non-fatal)', [
                'ticket_id' => $ticket->ticket_id,
                'error'     => $e->getMessage(),
            ]);
        }
    }

    // ─── API: AI ticket analysis ──────────────────────────────────────────────

    /**
     * POST /api/staging-tickets/{id}/analyze
     * Analisa AI (skill "sap-ticket-analyzer") untuk bantu validasi: overview,
     * dugaan akar masalah, saran klasifikasi, dan saran assignee.
     *
     * Dipanggil OTOMATIS oleh frontend begitu admin membuka satu staging
     * ticket unvalidated (bukan tombol manual) — dan secara default cuma
     * benar-benar memanggil AI SEKALI (ditegakkan lewat klaim atomic di
     * kolom ai_analysis_status: baris klaim di bawah cuma sukses kalau
     * statusnya masih NULL, jadi walau dua admin buka tiket yang sama
     * bersamaan, cuma satu yang benar-benar sampai memanggil provider AI).
     *
     * Admin/validator bisa memicu ulang secara sengaja lewat tombol
     * "Re-analyze" di panel — itu mengirim `force: true` di body request,
     * yang mengizinkan klaim ulang selama status SAAT INI bukan 'pending'
     * (supaya tidak menabrak request lain yang sedang berjalan). Hasil
     * re-analyze menimpa ai_analysis/ai_analysis_generated_at/_by yang lama.
     *
     * 'pending' yang TERLANTAR (baris ini diklaim, lalu proses yang
     * mengklaimnya mati di tengah jalan — timeout, worker di-recycle, PHP
     * fatal error yang lolos dari try/catch di bawah — sebelum sempat
     * menulis 'completed'/'failed') SEBALIKNYA HARUS bisa diklaim ulang,
     * oleh auto-trigger maupun Re-analyze, atau tiket itu terkunci selamanya
     * — insiden nyata: staging #316 macet di 'pending' >6 jam karena ini.
     * Lihat STALE_PENDING_MINUTES.
     */
    public function analyze(Request $request, $id, \App\Services\Ai\AiTicketAnalyzerService $analyzer)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $roleId = $sessionUser['role']['id'];
        if (!$this->canManageStagingTicket($roleId)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $staging = StagingTicket::findOrFail($id);

        if ($staging->isProcessed()) {
            return response()->json([
                'success' => false,
                'message' => 'Ticket has already been validated/rejected — analysis is no longer relevant.',
            ], 422);
        }

        $forceReanalyze = $request->boolean('force');
        $staleBefore = now()->subMinutes(self::STALE_PENDING_MINUTES);

        // Auto trigger: klaim kalau belum pernah dicoba sama sekali (NULL),
        // ATAU 'pending' tapi sudah terlantar lebih lama dari ambang di atas.
        // Re-analyze manual: itu plus status completed/failed (jadi semuanya
        // boleh dipicu ulang KECUALI 'pending' yang masih segar).
        //
        // Semua kondisi dibungkus SATU closure di bawah supaya AND id=? tetap
        // mengikat SELURUH sisi OR — tanpa ini, salah satu orWhere() lepas
        // dari scope id dan bisa ikut meng-klaim baris staging ticket lain.
        $claimed = StagingTicket::where('id', $id)
            ->where(function ($q) use ($forceReanalyze, $staleBefore) {
                $q->whereNull('ai_analysis_status')
                    ->orWhere(function ($stale) use ($staleBefore) {
                        $stale->where('ai_analysis_status', 'pending')
                            ->where('updated_at', '<', $staleBefore);
                    });

                if ($forceReanalyze) {
                    $q->orWhereIn('ai_analysis_status', ['completed', 'failed']);
                }
            })
            ->update(['ai_analysis_status' => 'pending']);

        if (!$claimed) {
            // Sudah pernah diklaim sebelumnya (oleh request ini sendiri yang
            // dipanggil dobel, request lain yang sedang berjalan, atau memang
            // sudah selesai/gagal dan ini bukan re-analyze) — jangan panggil
            // AI lagi, cukup laporkan state yang ada sekarang.
            $staging->refresh();

            if ('completed' === $staging->ai_analysis_status && $staging->ai_analysis) {
                // Cache ini bisa saja dibuat oleh actor LAIN (siapa pun yang
                // memicu analyze() pertama kali) yang punya izin credential —
                // gerbang yang sama dengan canViewAiAnalysis()/formatStaging()
                // supaya jalur "sudah completed, tinggal kembalikan cache" ini
                // tidak jadi jalan belakang buat actor yang tidak punya izin.
                $hasCredentialPermission = (bool) Employee::find($sessionUser['id'] ?? null)?->hasMenuPermission('customer.section.credential.view');
                $customerIdsWithCredentials = (!$hasCredentialPermission && $staging->customer_id && CustomerCredential::where('customer_id', $staging->customer_id)->exists())
                    ? [$staging->customer_id]
                    : [];

                if (!$this->canViewAiAnalysis(false, $hasCredentialPermission, $staging->customer_id, $customerIdsWithCredentials)) {
                    return response()->json([
                        'success' => false,
                        'message' => 'This ticket already has an AI analysis, but it references this customer\'s stored credential notes. You need "Customer Credential" view access to see it — ask an admin, or fill in the classification manually.',
                        'status'  => 'restricted',
                    ], 403);
                }

                return response()->json(['success' => true, 'data' => $staging->ai_analysis]);
            }

            if ('pending' === $staging->ai_analysis_status) {
                return response()->json([
                    'success' => false,
                    'message' => 'AI analysis for this ticket is already running, please wait a moment and try '
                        . 'again. (If this message keeps appearing for several minutes, the previous attempt likely '
                        . 'stalled — it will automatically become retryable after '
                        . self::STALE_PENDING_MINUTES . ' minutes.)',
                    'status'  => 'pending',
                ], 409);
            }

            return response()->json([
                'success' => false,
                'message' => 'AI analysis for this ticket has already been tried and failed. Use the Re-analyze button to try again, or fill in the classification manually.',
                'status'  => 'failed',
            ], 409);
        }

        // $staging di atas (baris findOrFail) dimuat SEBELUM klaim di atas —
        // klaimnya sendiri jalan lewat query builder terpisah (StagingTicket::
        // where(...)->update(...)), yang mengubah barisnya di DB tapi TIDAK
        // pernah menyentuh object $staging yang sudah telanjur ada di memori.
        // Tanpa refresh ini, atribut ai_analysis_status di $staging masih versi
        // LAMA (mis. 'completed' dari analisa sebelumnya, pada re-analyze) —
        // dan saat AiTicketAnalyzerService::analyze() nanti memanggil
        // $staging->update(['ai_analysis_status' => 'completed', ...]),
        // Eloquent membandingkan ke atribut lama itu, melihat 'completed' →
        // 'completed' TIDAK berubah, dan diam-diam MEMBUANG kolom itu dari
        // SQL UPDATE yang sungguhan dijalankan — kolom lain (ai_analysis,
        // generated_at/_by) tetap tersimpan karena isinya memang beda, tapi
        // status-nya nyangkut di 'pending' hasil klaim di atas SELAMANYA
        // (baris berhasil dianalisa AI-nya, tapi UI tidak pernah tahu).
        // Insiden nyata: staging #316 & #317 — audit log membuktikan
        // analisanya sukses, tapi ai_analysis_status tetap 'pending' berjam-
        // jam sesudahnya, tepat pola bug ini.
        $staging->refresh();

        // Agent Skill via code-execution container bisa makan waktu beberapa menit
        // (provisioning container + Claude baca file skill + reasoning effort tinggi)
        // — jauh di atas 60s yang tadinya dipasang di sini, yang bikin PHP fatal
        // duluan sebelum respons Anthropic sempat balik. Dibatasi 630s (bukan
        // unlimited) supaya selaras dengan timeout HTTP client di
        // AppServiceProvider (600s) — kalau Guzzle-nya sendiri gagal timeout
        // karena sebab lain, PHP tetap punya batas keras dan tidak menggantung
        // worker selamanya.
        set_time_limit(630);

        // Lepas kunci file session sebelum stream panjang, supaya tab lain
        // milik user yang sama tidak ikut menunggu — pola sama AiTicketSummaryController.
        $request->session()->save();

        return response()->stream(function () use ($analyzer, $staging, $id, $sessionUser, $roleId) {
            set_time_limit(630);

            $send = function (string $event, array $payload): void {
                echo 'event: ' . $event . "\n";
                echo 'data: ' . json_encode($payload) . "\n\n";
                if (ob_get_level() > 0) {
                    @ob_flush();
                }
                flush();
            };

            $isAborted = fn (): bool => 1 === connection_aborted();

            try {
                $result = $analyzer->analyze(
                    staging: $staging,
                    actorId: (int) $sessionUser['id'],
                    actorRoleId: $roleId,
                    actorName: $sessionUser['name'] ?? null,
                    onEvent: fn (string $event, array $payload) => $send($event, $payload),
                    isAborted: $isAborted,
                );

                $send('done', ['data' => $result]);
            } catch (\Anthropic\Core\Exceptions\AuthenticationException |
                     \Anthropic\Core\Exceptions\PermissionDeniedException |
                     \Anthropic\Core\Exceptions\BadRequestException |
                     \Anthropic\Core\Exceptions\NotFoundException $e) {
                // Konfigurasi/kredit/otentikasi bermasalah di sisi provider — mencoba
                // lagi TIDAK akan membantu sampai penyebabnya dibenahi (mis. saldo
                // Anthropic/OpenAI habis, API key dicabut, skill ID salah). Dibedakan
                // dari error transient di bawah supaya log-nya bisa dipantau/
                // di-alert terpisah dari sekadar gangguan jaringan sesaat.
                $this->logAndMarkAnalyzeFailure($id, $e, retryable: false);
                $send('error', ['message' => self::ANALYZE_FAILURE_MESSAGE]);
            } catch (\OpenAI\Exceptions\ErrorException $e) {
                $retryable = !in_array($e->getStatusCode(), [400, 401, 403, 404], true);
                $this->logAndMarkAnalyzeFailure($id, $e, retryable: $retryable);
                $send('error', ['message' => self::ANALYZE_FAILURE_MESSAGE]);
            } catch (\Anthropic\Core\Exceptions\RateLimitException |
                     \Anthropic\Core\Exceptions\InternalServerException |
                     \Anthropic\Core\Exceptions\APIConnectionException |
                     \OpenAI\Exceptions\RateLimitException |
                     \OpenAI\Exceptions\ServerException |
                     \OpenAI\Exceptions\TransporterException $e) {
                // Rate limit / server sibuk / koneksi terputus — genuinely transient,
                // retry (termasuk retry otomatis bawaan SDK) punya peluang berhasil.
                $this->logAndMarkAnalyzeFailure($id, $e, retryable: true);
                $send('error', ['message' => self::ANALYZE_FAILURE_MESSAGE]);
            } catch (\RuntimeException $e) {
                // Guard rail internal AiTicketAnalyzerService sendiri (skill ID belum
                // diisi di .env, jawaban AI gagal di-parse sebagai JSON valid, atau
                // koneksi ditutup user di tengah stream) — bukan outage provider,
                // tapi tetap bukan sesuatu yang pasti akan beda hasilnya kalau
                // di-retry begitu saja.
                $this->logAndMarkAnalyzeFailure($id, $e, retryable: true);
                if (0 === connection_aborted()) {
                    $send('error', ['message' => self::ANALYZE_FAILURE_MESSAGE]);
                }
            } catch (\Throwable $e) {
                $this->logAndMarkAnalyzeFailure($id, $e, retryable: true);
                $send('error', ['message' => self::ANALYZE_FAILURE_MESSAGE]);
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-transform',
            'X-Accel-Buffering' => 'no',
            'Connection' => 'keep-alive',
        ]);
    }

    /** Pesan yang dilihat admin yang lagi validasi tiket — SAMA di semua jenis kegagalan analyze(). */
    private const ANALYZE_FAILURE_MESSAGE = 'AI analysis failed for this ticket. Use the Re-analyze button to try again, or fill in the classification (Type/Priority/Scale/Module) manually.';

    /**
     * Satu titik keluar untuk semua kegagalan analyze() — menandai
     * ai_analysis_status='failed' (admin masih bisa memicu ulang lewat tombol
     * Re-analyze, tapi TIDAK ada retry otomatis dari sisi sistem), lalu log
     * level & pesan diagnostik dibedakan berdasarkan apakah penyebabnya
     * genuinely transient ($retryable, buat dipantau ops) atau butuh campur
     * tangan admin sistem (billing/config).
     *
     * Dulu method ini juga membentuk response JSON (analyzeFailureResponse(),
     * dengan status HTTP 503/502 dibedakan by $retryable) — sejak analyze()
     * jadi SSE, badan responsnya sudah dikirim (event `error`) SEBELUM
     * exception ini ditangani, jadi status code HTTP tidak relevan lagi di
     * sini; frontend sudah lama tidak membedakan 409/502/503 sama sekali,
     * cuma baca `message`.
     */
    private function logAndMarkAnalyzeFailure(int|string $stagingId, \Throwable $e, bool $retryable): void
    {
        StagingTicket::where('id', $stagingId)->update(['ai_analysis_status' => 'failed']);

        $context = [
            'staging_id' => $stagingId,
            'exception'  => get_class($e),
            'error'      => $e->getMessage(),
        ];

        if (!$retryable) {
            Log::critical('StagingTicketController@analyze: non-retryable AI provider error', $context);
        } else {
            Log::error('StagingTicketController@analyze: failed to analyze (transient)', $context);
        }
    }

    /**
     * Peran yang boleh mengelola staging ticket secara umum — SAMA PERSIS
     * dengan gerbang role di view() (halaman /staging-tickets sendiri), jadi
     * siapa pun yang bisa membuka halaman ini otomatis lolos di semua endpoint
     * di bawah, tidak ada yang diam-diam ter-403 padahal sedang lihat halamannya.
     * Dipakai bersama oleh:
     *   - analyze() & ask()   — dua pintu masuk fitur AI Analyzer (memicu
     *                           analisa AI / bertanya lewat panelnya)
     *   - statistics()        — badge Pending/Approved/Rejected
     *   - latestUpdate()      — polling ringan (cuma cek ada perubahan atau tidak)
     * Kalau daftar peran ini berubah, keempat fitur di atas ikut berubah
     * bersamaan — itu yang diinginkan, bukan efek samping.
     */
    private function canManageStagingTicket(?int $roleId): bool
    {
        return in_array($roleId, array_merge(
            [RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value],
            RoleId::STAGING_GROUP,
        ), true);
    }

    /**
     * POST /api/staging-tickets/{id}/ask
     * Tanya-jawab interaktif atas staging ticket yang sedang divalidasi (lihat
     * AiTicketQaService) — SSE, bentuknya sama persis dengan
     * AiAssistantController::chat(). Beda dari analyze(): endpoint ini boleh
     * dipanggil berkali-kali per tiket (satu giliran chat per request), dan
     * tidak butuh klaim atomic seperti ai_analysis_status — tidak ada state
     * bersama yang diperebutkan, tiap sesi (session_id, dibuat baru oleh
     * frontend setiap modal validasi dibuka) sudah terisolasi sendiri-sendiri
     * lewat AiTicketQaService::cacheKey().
     */
    public function ask(Request $request, $id, \App\Services\Ai\AiTicketQaService $qa): StreamedResponse
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $roleId = $sessionUser['role']['id'] ?? null;
        if (!$this->canManageStagingTicket($roleId)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'session_id' => 'required|string|max:100',
            'message' => 'required|string|max:2000',
        ]);

        $staging = StagingTicket::findOrFail($id);

        if ($staging->isProcessed()) {
            return response()->json([
                'success' => false,
                'message' => 'This ticket has already been validated/rejected — asking about it is no longer relevant.',
            ], 422);
        }

        $employee = Employee::find($sessionUser['id']);
        if (!$employee) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        // Lepas lock session sebelum stream panjang, supaya tab/request lain
        // milik user yang sama tidak ikut terblokir — sama seperti analyze().
        $request->session()->save();

        return response()->stream(function () use ($employee, $staging, $validated, $qa, $sessionUser, $roleId) {
            set_time_limit(0);

            $send = function (string $event, array $payload): void {
                echo 'event: ' . $event . "\n";
                echo 'data: ' . json_encode($payload) . "\n\n";
                if (ob_get_level() > 0) {
                    @ob_flush();
                }
                flush();
            };

            try {
                $qa->streamReply(
                    employee: $employee,
                    staging: $staging,
                    sessionId: $validated['session_id'],
                    userText: trim($validated['message']),
                    onDelta: function (string $text) use ($send): void {
                        $send('delta', ['text' => $text]);
                    },
                    isAborted: fn () => 1 === connection_aborted(),
                    actorRoleId: $roleId,
                    actorName: $sessionUser['name'] ?? null,
                );

                if (0 === connection_aborted()) {
                    $send('done', []);
                }
            } catch (\Throwable $e) {
                Log::error('Staging ticket Q&A failed', ['staging_id' => $staging->id, 'error' => $e->getMessage()]);
                if (0 === connection_aborted()) {
                    $send('error', ['message' => 'Something went wrong while answering. Please try again.']);
                }
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache',
            'X-Accel-Buffering' => 'no',
        ]);
    }

    // ─── API: Admin reject ────────────────────────────────────────────────────

    /**
     * POST /api/staging-tickets/{id}/reject
     * Admin menolak staging ticket.
     */
    public function reject(Request $request, $id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $roleId = $sessionUser['role']['id'];
        if (!in_array($roleId, array_merge([RoleId::EC_ADMINISTRATOR->value, RoleId::DELIVERY_SUPPORT_USER->value], RoleId::STAGING_GROUP), true)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'reason' => 'required|string|max:1000',
        ]);

        $staging = StagingTicket::findOrFail($id);

        try {
            $this->service->reject($staging, $sessionUser['id'], $request->reason);

            // Sync penolakan ke JARVIES DB
            $this->syncRejectionToJarvies($staging);

            // Notifikasi bell Jarvies — ticket request ditolak
            if ($staging->customer_id) {
                \App\Services\CustomerNotificationService::notify(
                    customerId: (int) $staging->customer_id,
                    type:       'ticket_rejected',
                    ticketId:   null,
                    fromName:   'Helpdesk Support',
                    preview:    'Your ticket request has been rejected. Reason: ' . \Illuminate\Support\Str::limit($request->reason, 80),
                    link:       '/tickets',
                );
            }

            return response()->json([
                'success' => true,
                'message' => 'Ticket has been rejected.',
                'data'    => ['staging_id' => $staging->id, 'status' => 'rejected'],
            ]);
        } catch (\LogicException $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        } catch (\Exception $e) {
            Log::error('StagingTicketController@reject: failed to reject', [
                'staging_id' => $id,
                'error'      => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Failed to reject ticket',
            ], 500);
        }
    }

    // ─── API: Email attachment list from Graph ────────────────────────────────

    /**
     * GET /api/staging-tickets/{id}/email-attachments
     * Mengembalikan daftar attachment non-inline dari email di Graph API
     * (menggunakan staging.graph_message_id).
     * Digunakan modal validasi agar admin bisa lihat/download attachment sebelum approve.
     */
    public function emailAttachments($id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $staging = StagingTicket::findOrFail($id);

        if (!$staging->graph_message_id) {
            return response()->json(['success' => true, 'data' => []]);
        }

        try {
            $attachments = app(EmailController::class)
                ->listNonInlineAttachments($staging->graph_message_id);

            // Map ke format yang dipakai modal — tambahkan proxy URL per item
            // Gunakan API endpoint agar bisa diakses oleh Jarvies (bukan web route)
            $data = array_map(fn ($att) => [
                'id'            => $att['id'],
                'name'          => $att['name'],
                'size'          => $att['size'],
                'content_type'  => $att['contentType'] ?? $att['content_type'] ?? null,
                'is_inline'     => $att['isInline'] ?? false,
                'url'           => "/api/staging-tickets/{$id}/attachment-download?attId=" . urlencode($att['id']),
            ], $attachments);

            return response()->json(['success' => true, 'data' => $data]);
        } catch (\Exception $e) {
            Log::warning('StagingTicketController@emailAttachments: gagal fetch dari Graph', [
                'staging_id'       => $id,
                'graph_message_id' => $staging->graph_message_id,
                'error'            => $e->getMessage(),
            ]);
            return response()->json(['success' => true, 'data' => []]);
        }
    }

    // ─── API: Proxy download attachment dari Graph (untuk Jarvies & EcoSystem) ──

    /**
     * GET /api/staging-tickets/{id}/attachment-download?attId={graphAttachmentId}
     * Stream attachment langsung dari Graph API ke browser.
     * API endpoint — dapat diakses oleh Jarvies maupun EcoSystem.
     */
    public function emailAttachmentDownload(\Illuminate\Http\Request $request, $id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $attId = $request->query('attId');
        if (!$attId) {
            return response()->json(['success' => false, 'message' => 'Missing attId parameter'], 400);
        }

        $staging = StagingTicket::findOrFail($id);

        if (!$staging->graph_message_id) {
            return response()->json(['success' => false, 'message' => 'No email associated with this staging ticket'], 404);
        }

        try {
            $emailCtrl = app(EmailController::class);
            $token     = $emailCtrl->getAccessTokenPublic();
            $sender    = config('services.microsoft_graph.sender_email');
            $baseUrl   = rtrim(config('services.microsoft_graph.base_url', 'https://graph.microsoft.com/v1.0'), '/');

            $response = Http::withToken($token)->get(
                "{$baseUrl}/users/{$sender}/messages/{$staging->graph_message_id}/attachments/{$attId}"
            );

            if (!$response->successful()) {
                return response()->json(['success' => false, 'message' => 'Attachment not found'], 404);
            }

            $data         = $response->json();
            $contentBytes = base64_decode($data['contentBytes'] ?? '');
            $contentType  = $data['contentType'] ?? 'application/octet-stream';
            $name      = $data['name'] ?? 'attachment';
            $asciiName = str_replace(['"', '\\', "\r", "\n"], '', preg_replace('/[^\x20-\x7E]/', '_', $name));

            // Browser hanya punya viewer bawaan untuk image/PDF — tipe lain (docx, xlsx, zip, dst)
            // yang dipaksa 'inline' membuat browser fallback ke auto-download tanpa menghormati
            // nama file dari Content-Disposition, sehingga nama file berubah jadi acak/rusak.
            $isInline    = $data['isInline'] ?? (str_starts_with($contentType, 'image/') || $contentType === 'application/pdf');
            $disposition = $isInline ? 'inline' : 'attachment';

            return response($contentBytes, 200, [
                'Content-Type'        => $contentType,
                'Content-Disposition' => $disposition . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name),
                'Content-Length'      => strlen($contentBytes),
            ]);
        } catch (\Exception $e) {
            Log::warning('StagingTicketController@emailAttachmentDownload: gagal', [
                'staging_id' => $id,
                'att_id'     => $attId,
                'error'      => $e->getMessage(),
            ]);
            return response()->json(['success' => false, 'message' => 'Failed to retrieve attachment'], 500);
        }
    }

    // ─── Web: Proxy download email attachment dari Graph ─────────────────────

    /**
     * GET /staging-email-attachments/{stagingId}?attId={graphAttachmentId}
     * Stream attachment langsung dari Graph API ke browser.
     * attId dikirim sebagai query parameter (bukan path) agar karakter khusus (=, +) tidak rusak di URL.
     */
    public function proxyEmailAttachment(\Illuminate\Http\Request $request, $stagingId)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            abort(401, 'Authentication required. Please log in to access this resource.');
        }

        $attId = $request->query('attId');
        if (!$attId) {
            abort(400, 'Missing attId parameter.');
        }

        $staging = StagingTicket::findOrFail($stagingId);

        if (!$staging->graph_message_id) {
            abort(404, 'No email associated with this staging ticket.');
        }

        try {
            $emailCtrl = app(EmailController::class);
            $token     = $emailCtrl->getAccessTokenPublic();
            $sender    = config('services.microsoft_graph.sender_email');
            $baseUrl   = rtrim(config('services.microsoft_graph.base_url', 'https://graph.microsoft.com/v1.0'), '/');

            $response = Http::withToken($token)->get(
                "{$baseUrl}/users/{$sender}/messages/{$staging->graph_message_id}/attachments/{$attId}"
            );

            if (!$response->successful()) {
                abort(404, 'Attachment not found.');
            }

            $data         = $response->json();
            $contentBytes = base64_decode($data['contentBytes'] ?? '');
            $contentType  = $data['contentType'] ?? 'application/octet-stream';
            $name      = $data['name'] ?? 'attachment';
            $asciiName = str_replace(['"', '\\', "\r", "\n"], '', preg_replace('/[^\x20-\x7E]/', '_', $name));

            // Browser hanya punya viewer bawaan untuk image/PDF — tipe lain (docx, xlsx, zip, dst)
            // yang dipaksa 'inline' membuat browser fallback ke auto-download tanpa menghormati
            // nama file dari Content-Disposition, sehingga nama file berubah jadi acak/rusak.
            $isInline    = $data['isInline'] ?? (str_starts_with($contentType, 'image/') || $contentType === 'application/pdf');
            $disposition = $isInline ? 'inline' : 'attachment';

            return response($contentBytes, 200, [
                'Content-Type'        => $contentType,
                'Content-Disposition' => $disposition . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name),
                'Content-Length'      => strlen($contentBytes),
            ]);
        } catch (\Exception $e) {
            abort(500, 'Failed to retrieve attachment.');
        }
    }

    // ─── API: Email body preview (resolve inline images as base64) ───────────

    /**
     * GET /api/staging-tickets/{id}/preview-body
     * Mengembalikan email_body_html dengan cid: inline images diganti base64 data URI.
     * Digunakan oleh modal staging agar gambar bisa ditampilkan sebelum ticket di-approve.
     */
    public function previewBody($id)
    {
        $sessionUser = session('user');
        if (!$sessionUser) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $staging = StagingTicket::findOrFail($id);
        $html    = $staging->email_body_html ?? '';

        // Fallback: jika email_body_html kosong tapi graph_message_id ada,
        // fetch body langsung dari Graph (untuk staging lama atau web tickets yang baru dapat graph_message_id)
        if (!$html && $staging->graph_message_id) {
            try {
                $sender   = config('services.microsoft_graph.sender_email');
                $emailCtrl = app(EmailController::class);
                $msg = $emailCtrl->graphGetPublic(
                    "/users/{$sender}/messages/{$staging->graph_message_id}",
                    ['$select' => 'body']
                );
                $html = $msg['body']['content'] ?? '';
                // Simpan ke DB agar request berikutnya tidak perlu fetch ulang
                if ($html) {
                    $staging->update(['email_body_html' => $html]);
                }
            } catch (\Exception $e) {
                Log::warning('StagingTicketController@previewBody: gagal fetch body dari Graph', [
                    'staging_id'       => $staging->id,
                    'graph_message_id' => $staging->graph_message_id,
                    'error'            => $e->getMessage(),
                ]);
            }
        }

        $needsResolve = $staging->graph_message_id && (
            str_contains($html, 'cid:') ||
            ($staging->has_attachments && preg_match('/\[[^\]]+\.(png|jpe?g|gif|bmp|webp)\]/i', $html))
        );
        if ($html && $needsResolve) {
            try {
                $html = app(\App\Http\Controllers\EmailController::class)
                    ->resolveInlineImagesAsDataUris($staging->graph_message_id, $html);
            } catch (\Exception $e) {
                Log::warning('StagingTicketController@previewBody: resolve images failed', [
                    'staging_id' => $staging->id,
                    'error'      => $e->getMessage(),
                ]);
            }
        }

        return response()->json(['success' => true, 'html' => $html]);
    }

    // ─── API: Lightweight polling check ───────────────────────────────────────

    /**
     * GET /api/staging-tickets/latest-update
     *
     * Endpoint ringan untuk polling — cuma satu MAX(updated_at), tidak
     * menyentuh Graph API atau eager-load relasi apa pun. Pola yang sama
     * dengan TicketController::latestUpdate() untuk daftar tiket utama.
     * Frontend (staging/index.blade.php) memanggil ini tiap beberapa detik
     * dan HANYA menarik ulang list/stats penuh kalau nilainya berubah dari
     * polling sebelumnya — supaya polling 30 detik tidak selalu re-fetch
     * seluruh halaman walau tidak ada perubahan sama sekali.
     */
    public function latestUpdate()
    {
        $sessionUser = session('user');
        if (!$sessionUser || !$this->canManageStagingTicket($sessionUser['role']['id'] ?? null)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $latest = StagingTicket::max('updated_at');

        return response()->json(['latest_update' => $latest]);
    }

    // ─── API: Statistics (untuk badge/notif admin) ────────────────────────────

    /**
     * GET /api/staging-tickets/statistics
     */
    public function statistics()
    {
        $sessionUser = session('user');
        if (!$sessionUser || !$this->canManageStagingTicket($sessionUser['role']['id'] ?? null)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        // Satu query GROUP BY, bukan 4 COUNT terpisah (unvalidated/approved/
        // rejected/total) — status hanya punya 3 nilai yang mungkin (lihat
        // scopeUnvalidated/Approved/Rejected), jadi cukup satu pass lalu
        // dijumlah di PHP untuk total.
        $counts = StagingTicket::selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return response()->json([
            'success' => true,
            'data' => [
                'unvalidated' => (int) ($counts['unvalidated'] ?? 0),
                'approved'    => (int) ($counts['approved'] ?? 0),
                'rejected'    => (int) ($counts['rejected'] ?? 0),
                'total'       => (int) $counts->sum(),
            ],
        ]);
    }

    // ─── Private: Assign ticket ke delivery support saat validasi ───────────

    private function assignTicketToDeliverySupport(Ticket $ticket, int $supportId): void
    {
        $support = DB::table('delivery_support')->where('id', $supportId)->first();
        if (!$support) {
            Log::warning('StagingTicketController@assignTicketToDeliverySupport: delivery support not found', [
                'ticket_id'  => $ticket->ticket_id,
                'support_id' => $supportId,
            ]);
            return;
        }

        // Cegah duplikat assignment
        $alreadyAssigned = DB::table('delivery_support_activities')
            ->where('delivery_support_id', $supportId)
            ->where('ticket_id', $ticket->ticket_id)
            ->exists();

        if ($alreadyAssigned) {
            app(\App\Services\SlaService::class)->syncPolicy($ticket, $supportId);
            return;
        }

        // Cari phase default (system default → fallback: phase aktif pertama)
        $phase = DB::table('delivery_support_phases')
            ->where('delivery_support_id', $supportId)
            ->where('is_system_default', true)
            ->first()
            ?? DB::table('delivery_support_phases')
                ->where('delivery_support_id', $supportId)
                ->where('is_active', true)
                ->first();

        if (!$phase) {
            Log::warning('StagingTicketController@assignTicketToDeliverySupport: no active phase found', [
                'ticket_id'  => $ticket->ticket_id,
                'support_id' => $supportId,
            ]);
            app(\App\Services\SlaService::class)->syncPolicy($ticket, $supportId);
            return;
        }

        $group = DB::table('delivery_support_planning')
            ->where('delivery_support_id', $supportId)
            ->where('phase_id', $phase->id)
            ->where('is_group', true)
            ->first();

        $nextOrder = DB::table('delivery_support_activities')
            ->where('delivery_support_id', $supportId)
            ->where('delivery_support_phase_id', $phase->id)
            ->max('order_sequence') + 1;

        $complexity = match (strtolower($ticket->ticket_priority ?? '')) {
            'very high', 'high' => 'complex',
            'low'               => 'simple',
            default             => 'medium',
        };

        $status = match ($ticket->status ?? '') {
            'inprocess', 'waiting_on_customer', 'waiting_on_3rd_party', 'waiting_to_confirmation' => 'in_progress',
            'hold'                  => 'on_hold',
            'closed', 'cancelled'  => 'completed',
            default                => 'not_started',
        };

        DB::transaction(function () use ($ticket, $supportId, $phase, $group, $nextOrder, $complexity, $status) {
            $activityId = DB::table('delivery_support_activities')->insertGetId([
                'delivery_support_id'       => $supportId,
                'delivery_support_phase_id' => $phase->id,
                'ticket_id'                 => $ticket->ticket_id,
                'stage_id'                  => null,
                'name'                      => $ticket->ticket_number . ' - ' . ($ticket->description ?? "Ticket #{$ticket->ticket_id}"),
                'description'               => $ticket->description,
                'order_sequence'            => $nextOrder,
                'module'                    => null,
                'new_issue'                 => true,
                'object'                    => null,
                'incident_type'             => 'incident',
                'complexity'                => $complexity,
                'deliverable'               => null,
                'start_date'                => $ticket->start_date ?? now(),
                'end_date'                  => $ticket->end_date,
                'status'                    => $status,
                'progress_percentage'       => 0,
                'weight'                    => $ticket->man_days ?? 1,
                'notes'                     => "Auto-created from Ticket #{$ticket->ticket_id}",
                'created_at'                => now(),
                'updated_at'                => now(),
            ]);

            $planningId = null;
            if ($group) {
                $planningId = DB::table('delivery_support_planning')->insertGetId([
                    'delivery_support_id' => $supportId,
                    'phase_id'            => $phase->id,
                    'parent_id'           => $group->id,
                    'activity_id'         => $activityId,
                    'name'                => $ticket->ticket_number . ' - ' . ($ticket->description ?? "Ticket #{$ticket->ticket_id}"),
                    'is_group'            => false,
                    'level'               => 1,
                    'order_sequence'      => $nextOrder,
                    'start_date'          => $ticket->start_date ?? now(),
                    'end_date'            => $ticket->end_date,
                    'weight'              => $ticket->man_days ?? 1,
                    'status'              => $status,
                    'progress_percentage' => 0,
                    'created_at'          => now(),
                    'updated_at'          => now(),
                ]);
            }

            AuditLog::recordAction(
                module: 'Delivery Support',
                auditableType: 'DeliverySupport',
                auditableId: $supportId,
                event: 'updated',
                recordLabel: "Delivery Support #{$supportId}",
                description: "assigned Ticket #{$ticket->ticket_number} to Delivery Support #{$supportId} (staging validation)",
                old: null,
                new: [
                    'ticket_id' => $ticket->ticket_id,
                    'ticket_number' => $ticket->ticket_number,
                    'activity_id' => $activityId,
                    'planning_id' => $planningId,
                    'phase_id' => $phase->id,
                ],
            );
        });

        app(\App\Services\SlaService::class)->syncPolicy($ticket, $supportId);

        Log::info('StagingTicketController@assignTicketToDeliverySupport: ticket assigned at validation time', [
            'ticket_id'  => $ticket->ticket_id,
            'support_id' => $supportId,
        ]);
    }

    // ─── Private: Sync ke JARVIES DB setelah validasi ────────────────────────

    private function syncApprovalToJarvies(StagingTicket $staging, Ticket $ticket): void
    {
        $url = rtrim(config('services.jarvies.url', ''), '/');
        $key = config('services.jarvies.api_key');
        if (!$url || !$key) return;

        try {
            Http::withHeaders(['X-Api-Key' => $key])
                ->timeout(15)
                ->post("{$url}/api/ecosystem/staging-approved", [
                    'customer_id'        => $staging->customer_id,
                    'staging_description'=> $staging->description,
                    'ticket_id'          => $ticket->ticket_id,
                    'ticket_number'      => $ticket->ticket_number,
                    'description'        => $ticket->description,
                    'status'             => $ticket->status,
                    'ticket_priority'    => $ticket->ticket_priority,
                    'ticket_type'        => $ticket->ticket_type,
                    'channel'            => $ticket->channel,
                    'submitted_by_email' => $ticket->submitted_by_email,
                    'submitted_by_name'  => $ticket->submitted_by_name,
                    'start_date'         => $ticket->start_date?->toDateString(),
                ]);

            Log::info('StagingTicketController@syncApprovalToJarvies: berhasil', [
                'staging_id' => $staging->id,
                'ticket_id'  => $ticket->ticket_id,
            ]);
        } catch (\Exception $e) {
            Log::warning('StagingTicketController@syncApprovalToJarvies: gagal (non-fatal)', [
                'staging_id' => $staging->id,
                'error'      => $e->getMessage(),
            ]);
        }
    }

    private function syncRejectionToJarvies(StagingTicket $staging): void
    {
        $url = rtrim(config('services.jarvies.url', ''), '/');
        $key = config('services.jarvies.api_key');
        if (!$url || !$key) return;

        try {
            Http::withHeaders(['X-Api-Key' => $key])
                ->timeout(15)
                ->post("{$url}/api/ecosystem/staging-rejected", [
                    'customer_id'        => $staging->customer_id,
                    'staging_description'=> $staging->description,
                    'rejection_reason'   => $staging->rejection_reason,
                ]);
        } catch (\Exception $e) {
            Log::warning('StagingTicketController@syncRejectionToJarvies: gagal (non-fatal)', [
                'staging_id' => $staging->id,
                'error'      => $e->getMessage(),
            ]);
        }
    }

    // ─── Private: Notifikasi balasan otomatis setelah approval ───────────────

    /**
     * Kirim balasan otomatis ke customer saat staging ticket disetujui.
     *
     * - Untuk semua channel: simpan TicketMessage ke DB (tampil di Jarvies)
     * - Untuk email channel: juga kirim email via Graph API
     *
     * Template:
     *   "Baik akan disampaikan dengan Nomor Ticket XXXX
     *   Best Regards,
     *   {nama helpdesk}"
     *
     * Subject email: "{ticket_number}, {original_subject}"
     * Contoh: "2603-CUST-000001, issue maret"
     */
    private function sendApprovalNotification(StagingTicket $staging, Ticket $ticket, array $sessionUser, ?TicketMessage $firstMessage = null): void
    {
        // Pastikan PHP tidak timeout — Graph API bisa memakan 20-60 detik di server production
        // (token fetch + attachment download + createReply + send = banyak HTTP round trips)
        set_time_limit(180);

        try {
            Log::info('StagingTicketController@sendApprovalNotification: mulai', [
                'staging_id'         => $staging->id,
                'ticket_id'          => $ticket->ticket_id,
                'channel'            => $staging->channel,
                'has_graph_msg'      => !empty($staging->graph_message_id),
                'submitted_by_email' => $staging->submitted_by_email,
            ]);

            // ── Ambil nama pengirim (helpdesk yang approve) ──
            $nickName = $sessionUser['nick_name'] ?? null;
            if (!$nickName) {
                $nickName = DB::table('employee_basic_data')
                    ->where('employee_id', $sessionUser['id'])
                    ->value('nick_name');
            }
            $signatureName = $nickName ?? explode(' ', $sessionUser['name'] ?? 'Helpdesk')[0];

            $ticketNumber = $ticket->ticket_number ?? '—';

            // Bangun detail tiket (metadata: phone, module, client, description)
            // agar email approval berisi isi tiket yang sama seperti tampilan Jarvies
            $detailRows = '';
            if (!empty($staging->no_hp))  $detailRows .= '<tr><td style="padding:4px 12px 4px 0;font-weight:600;color:#555;white-space:nowrap">Phone</td><td>' . e($staging->no_hp)  . '</td></tr>';
            if (!empty($staging->module)) $detailRows .= '<tr><td style="padding:4px 12px 4px 0;font-weight:600;color:#555;white-space:nowrap">Module</td><td>' . e($staging->module) . '</td></tr>';
            if (!empty($staging->client)) $detailRows .= '<tr><td style="padding:4px 12px 4px 0;font-weight:600;color:#555;white-space:nowrap">Client</td><td>' . e($staging->client) . '</td></tr>';

            $metaTable = $detailRows
                ? '<table style="border-collapse:collapse;margin-bottom:16px">' . $detailRows . '</table>'
                : '';

            $descSection = !empty($staging->body)
                ? '<div style="margin-bottom:16px"><strong>Description:</strong>'
                  . '<div style="margin-top:8px;padding:12px;background:#f9f9f9;border:1px solid #e0e0e0;border-radius:4px">'
                  . $staging->body
                  . '</div></div>'
                : '';

            $detailBlock = ($metaTable || $descSection)
                ? '<div style="margin:16px 0;padding:16px;background:#f9fafb;border-left:4px solid #c62828;border-radius:4px">'
                  . $metaTable . $descSection
                  . '</div>'
                : '';

            $bodyPlain = "Terima kasih sudah menghubungi kami.\n"
                       . "Kami sudah daftarkan tiket terkait issue yang sudah disampaikan dengan nomor {$ticketNumber}\n"
                       . "Issue tersebut akan segera kami teruskan kepada konsultan yang terkait untuk diproses.\n\n\n"
                       . "Regards,\nEclectic Support Team";

            $bodyHtml  = "<p>Terima kasih sudah menghubungi kami.<br>"
                       . "Kami sudah daftarkan tiket terkait issue yang sudah disampaikan dengan nomor <strong>{$ticketNumber}</strong><br>"
                       . "Issue tersebut akan segera kami teruskan kepada konsultan yang terkait untuk diproses.</p>"
                       . $detailBlock
                       . "<br><p>Regards,<br><strong>Eclectic Support Team</strong></p>";

            $safeNum  = htmlspecialchars($ticketNumber, ENT_QUOTES, 'UTF-8');
            $safeAgent = htmlspecialchars($signatureName, ENT_QUOTES, 'UTF-8');
            $safeDesc  = htmlspecialchars(mb_substr($staging->description ?? '', 0, 90), ENT_QUOTES, 'UTF-8');
            $bodyHtml  = <<<HTML
            <table width="100%" cellpadding="0" cellspacing="0" border="0"
                   style="font-family:Arial,Helvetica,sans-serif;max-width:600px;border-collapse:collapse;">
                <tr>
                    <td style="background-color:#8b1a1a;padding:16px 24px;border-radius:6px 6px 0 0;">
                        <p style="color:#ffffff;font-size:16px;font-weight:bold;margin:0;line-height:1.3;">PT Eclectic Consulting</p>
                        <p style="color:rgba(255,255,255,0.7);font-size:11px;margin:3px 0 0 0;">Helpdesk Support &nbsp;&middot;&nbsp; Ticket #{$safeNum}</p>
                    </td>
                </tr>
                <tr>
                    <td style="background-color:#ffffff;padding:24px;border-left:1px solid #e5e7eb;border-right:1px solid #e5e7eb;font-size:14px;color:#374151;line-height:1.7;">
                        <p style="margin:0 0 16px 0;">Terima kasih sudah menghubungi kami.<br>
                        Kami sudah daftarkan tiket terkait issue yang sudah disampaikan dengan nomor <strong>{$safeNum}</strong><br>
                        Issue tersebut akan segera kami teruskan kepada konsultan yang terkait untuk diproses.</p>
                        <p style="margin:0;">Regards,<br><strong>Eclectic Support Team</strong></p>
                    </td>
                </tr>
                <tr>
                    <td style="background-color:#f9fafb;padding:14px 24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 6px 6px;">
                        <p style="color:#9ca3af;font-size:11px;margin:0;line-height:1.6;">
                            Sent by <strong style="color:#6b7280;">{$safeAgent}</strong> &mdash; PT Eclectic Consulting<br>
                            Ticket: <strong style="color:#6b7280;">#{$safeNum}</strong> &mdash; {$safeDesc}
                        </p>
                    </td>
                </tr>
            </table>
            HTML;

            // ── Fetch forwarded attachments dari email asal (Graph) ────────────
            // Diunduh SEBELUM membangun bodyHtml agar nama file bisa ditampilkan
            // di section "Original Ticket Content" sekaligus dilampirkan ke email.
            $rawAttachments = [];
            Log::info('StagingTicketController@sendApprovalNotification: step fetch-attachments', [
                'staging_id'      => $staging->id,
                'graph_message_id'=> $staging->graph_message_id,
            ]);
            if ($staging->graph_message_id) {
                try {
                    $emailCtrl = app(EmailController::class);
                    $sender    = config('services.microsoft_graph.sender_email');
                    $token     = $emailCtrl->getAccessTokenPublic();
                    $baseUrl   = rtrim(config('services.microsoft_graph.base_url', 'https://graph.microsoft.com/v1.0'), '/');

                    $attList = $emailCtrl->listNonInlineAttachments($staging->graph_message_id);
                    foreach ($attList as $att) {
                        $attRes = \Illuminate\Support\Facades\Http::withToken($token)->get(
                            "{$baseUrl}/users/{$sender}/messages/{$staging->graph_message_id}/attachments/{$att['id']}"
                        );
                        if ($attRes->successful()) {
                            $data = $attRes->json();
                            if (!empty($data['contentBytes'])) {
                                $rawAttachments[] = [
                                    'name'  => $data['name'] ?? ($att['name'] ?? 'attachment'),
                                    'mime'  => $data['contentType'] ?? ($att['contentType'] ?? 'application/octet-stream'),
                                    'bytes' => base64_decode($data['contentBytes']),
                                ];
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::warning('StagingTicketController@sendApprovalNotification: gagal fetch original attachments', [
                        'staging_id'       => $staging->id,
                        'graph_message_id' => $staging->graph_message_id,
                        'error'            => $e->getMessage(),
                    ]);
                    // Non-fatal: lanjut kirim email tanpa attachment asal
                }
            }

            // Section "Original Ticket Content" sengaja DIHILANGKAN dari body email
            // (sesuai permintaan): customer cukup menerima pesan sambutan + nomor tiket.
            // $rawAttachments tetap dilampirkan sebagai attachment email yang sebenarnya.

            Log::info('StagingTicketController@sendApprovalNotification: step create-message', [
                'staging_id'      => $staging->id,
                'raw_att_count'   => count($rawAttachments),
            ]);

            // ── Simpan TicketMessage (tampil di semua channel — termasuk Jarvies web) ──
            $message = TicketMessage::create([
                'ticket_id'           => $ticket->ticket_id,
                'sender_type'         => 'employee',
                'sender_id'           => $sessionUser['id'],
                'sender_name'         => 'Helpdesk Support',
                'message'             => $bodyPlain,
                'message_html'        => $bodyHtml,
                'is_internal_note'    => false,
                'channel'             => $ticket->channel,
                'is_read_by_customer' => false,
                'is_read_by_agent'    => true,
            ]);

            $ticket->update([
                'last_agent_reply_at' => now(),
                'last_message_at'     => now(),
            ]);

            // ── Selalu kirim email ke customer jika ada alamat email ──────────────
            $customerEmail = $staging->submitted_by_email;
            if (!$customerEmail && $ticket->customer_id) {
                $customerEmail = Customer::find($ticket->customer_id)?->email;
            }

            Log::info('StagingTicketController@sendApprovalNotification: resolving customer email', [
                'staging_id'           => $staging->id,
                'ticket_id'            => $ticket->ticket_id,
                'submitted_by_email'   => $staging->submitted_by_email,
                'customer_email'       => $customerEmail,
                'email_message_id'     => $staging->email_message_id,
                'email_thread_id'      => $staging->email_thread_id,
            ]);

            Log::info('StagingTicketController@sendApprovalNotification: step send-email', [
                'staging_id'    => $staging->id,
                'customer_email'=> $customerEmail,
            ]);

            if ($customerEmail) {
                // Subject format: "[JARVIES] #26040014 : FIX BISA"
                // Format ini menjadi "anchor" subject thread email ticket. Semua email
                // berikutnya (reply helpdesk, status, mandays, deliverable) WAJIB memakai
                // format yang sama agar subjectTopicMatches() mengenali topik yang sama →
                // Thread-Index Exchange tidak ter-reset → semua tetap satu thread.
                $subject   = '[JARVIES] #' . $ticketNumber . ' : ' . ($staging->description ?? 'Ticket Update');
                $inReplyTo = $staging->email_message_id; // null untuk web-only → buat thread baru
                $threadId  = $staging->email_thread_id;   // conversationId fallback

                // Ambil CC dari staging — handle keduanya: PHP array (normal) dan JSON string (legacy/double-encode)
                $rawCc  = $staging->cc_emails;
                if (is_string($rawCc)) {
                    $rawCc = json_decode($rawCc, true) ?? [];
                }
                $ccList = is_array($rawCc) ? $rawCc : [];

                Log::info('StagingTicketController@sendApprovalNotification: sending email', [
                    'to'          => $customerEmail,
                    'subject'     => $subject,
                    'in_reply_to' => $inReplyTo,
                    'thread_id'   => $threadId,
                    'cc_count'    => count($ccList),
                ]);

                $emailResult = app(EmailController::class)->sendTicketReply(
                    $customerEmail,
                    $subject,
                    $bodyHtml,
                    $inReplyTo,
                    [],               // files
                    $ccList,          // ccList dari staging
                    true,             // noRePrefix = true → subject tidak ditambah "Re:"
                    $threadId,        // conversationId fallback
                    false,            // forceNewDraft = false → pakai createReply agar Exchange auto-set
                    $rawAttachments   // forward attachment dari email [Menunggu Validasi] asal
                );

                // Simpan conversationId ke ticket agar reply berikutnya threaded ke email
                // approval ini. PENTING: selalu overwrite, bukan hanya saat kosong.
                //
                // Alasan: Exchange mengubah conversationId saat subject di-patch jadi
                // "Ticket #XXXX: ..." (tanpa prefix "Re:"). Original convId dari email
                // customer → BEDA dengan convId approval. Jika kita tidak update, subsequent
                // reply (dari Jarvies/EcoSystem) akan createReply pada convId lama → Gmail
                // lihat sebagai thread baru terpisah dari thread approval.
                $newConvId = $emailResult['conversation_id'] ?? null;
                if ($newConvId) {
                    $ticket->update(['email_thread_id' => $newConvId]);
                }

                // Simpan internetMessageId + update channel ke 'email'
                // agar Jarvies bisa pakai sebagai In-Reply-To dan indicator thread aktif tampil
                $internetMsgId = $emailResult['internet_message_id'] ?? null;
                if ($internetMsgId) {
                    $message->update([
                        'email_message_id' => $internetMsgId,
                        'channel'          => 'email',
                    ]);
                }

                Log::info('StagingTicketController@sendApprovalNotification: email terkirim', [
                    'ticket_id'          => $ticket->ticket_id,
                    'internet_message_id'=> $internetMsgId,
                    'conversation_id'    => $newConvId,
                ]);
            } else {
                Log::warning('StagingTicketController@sendApprovalNotification: customer email tidak ditemukan, email dilewati', [
                    'staging_id'  => $staging->id,
                    'ticket_id'   => $ticket->ticket_id,
                    'customer_id' => $ticket->customer_id,
                ]);
            }

            Log::info('StagingTicketController@sendApprovalNotification: selesai', [
                'ticket_id'      => $ticket->ticket_id,
                'ticket_number'  => $ticketNumber,
                'email_sent'     => $customerEmail !== null,
            ]);

        } catch (\Exception $e) {
            Log::error('StagingTicketController@sendApprovalNotification: GAGAL', [
                'staging_id' => $staging->id,
                'ticket_id'  => $ticket->ticket_id,
                'error'      => $e->getMessage(),
                'class'      => get_class($e),
                'file'       => $e->getFile() . ':' . $e->getLine(),
                'trace'      => array_slice(
                    array_map(fn($f) => ($f['file'] ?? '?') . ':' . ($f['line'] ?? '?') . ' ' . ($f['function'] ?? ''),
                    $e->getTrace()), 0, 8
                ),
            ]);
            // Tidak throw — gagal notifikasi tidak membatalkan approval yang sudah berhasil
        }
    }

    // ─── Private: Email konfirmasi saat customer submit tiket ───────────────

    /**
     * Kirim email konfirmasi ke customer setelah staging ticket dibuat dari Jarvies.
     *
     * Email dikirim dari M365 helpdesk (Raditya) ke submitted_by_email customer.
     * Attachment dari form turut dilampirkan agar bisa diakses via Graph API
     * saat admin melakukan validasi staging ticket.
     *
     * Hasil pengiriman (conversation_id, graph_message_id, internet_message_id)
     * disimpan ke staging agar approval nanti bisa thread ke email ini.
     *
     * Non-fatal: gagal kirim email tidak membatalkan pembuatan staging.
     */
    private function sendSubmissionEmail(StagingTicket $staging, array $files, array $validated): void
    {
        $toEmail = $staging->submitted_by_email ?? ($validated['submitted_by_email'] ?? null);
        if (!$toEmail) {
            Log::info('StagingTicketController@sendSubmissionEmail: skip — no customer email', [
                'staging_id' => $staging->id,
            ]);
            return;
        }

        try {
            $subject  = '[No Reply] [Menunggu Validasi] ' . $staging->description;
            $bodyHtml = $this->buildStagingEmailBody($staging);

            // Decode cc_emails dari staging (sudah di-decode di awal jarviesStore)
            $rawCc  = $staging->cc_emails;
            if (is_string($rawCc)) {
                $rawCc = json_decode($rawCc, true) ?? [];
            }
            $ccList = is_array($rawCc) ? $rawCc : [];

            $emailResult = app(EmailController::class)->sendTicketReply(
                $toEmail,
                $subject,
                $bodyHtml,
                null,    // $inReplyTo — email baru, bukan reply
                $files,  // attachment dari form (UploadedFile[])
                $ccList,
                true,    // $noRePrefix — pakai subject apa adanya (sudah ada [PENDING])
                null     // $threadId
            );

            // Simpan identitas email ke staging agar approval bisa thread ke sini.
            // Ubah channel ke 'email' supaya modal validasi menampilkan email_body_html
            // (termasuk inline images dan attachment dari Graph) alih-alih body teks biasa.
            $staging->update([
                'email_thread_id'  => $emailResult['conversation_id']     ?? null,
                'graph_message_id' => $emailResult['graph_message_id']    ?? null,
                'email_message_id' => $emailResult['internet_message_id'] ?? null,
                'channel'          => 'email',
                'email_body_html'  => $bodyHtml,
            ]);

            Log::info('StagingTicketController@sendSubmissionEmail: email terkirim', [
                'staging_id'          => $staging->id,
                'to'                  => $toEmail,
                'internet_message_id' => $emailResult['internet_message_id'] ?? null,
            ]);

        } catch (\Exception $e) {
            Log::warning('StagingTicketController@sendSubmissionEmail: gagal kirim email', [
                'staging_id' => $staging->id,
                'to'         => $toEmail,
                'error'      => $e->getMessage(),
            ]);
            // Tidak throw — gagal email tidak membatalkan staging yang sudah dibuat
        }
    }

    /**
     * Link staging ticket ke email yang sudah dikirim Jarvies.
     *
     * Jarvies mengirim emailnya sendiri (subject "[Menunggu Validasi]") dan
     * mengoper internetMessageId ke API ini. EcoSystem mencari email tersebut
     * di Sent Items M365, lalu menyimpan graph_message_id, conversation_id,
     * email_body_html, dan mengubah channel ke 'email'.
     *
     * Setelah ini, modal validasi dapat menampilkan body email asli + attachment
     * yang terlampir di email tersebut via Graph API.
     *
     * Non-fatal: gagal link tidak membatalkan staging yang sudah dibuat.
     */
    private function linkStagingToEmail(StagingTicket $staging, string $internetMessageId): void
    {
        try {
            $sender    = config('services.microsoft_graph.sender_email');
            $emailCtrl = app(EmailController::class);
            $filterVal = str_replace("'", "''", $internetMessageId);

            // Cari di Sent Items (paling mungkin) lalu fallback global
            $graphMsgId     = null;
            $conversationId = null;
            foreach ([
                "/users/{$sender}/mailFolders/SentItems/messages",
                "/users/{$sender}/messages",
            ] as $path) {
                try {
                    $result = $emailCtrl->graphGetPublic($path, [
                        '$filter' => "internetMessageId eq '{$filterVal}'",
                        '$select' => 'id,conversationId',
                        '$top'    => 1,
                    ]);
                    if (!empty($result['value'][0]['id'])) {
                        $graphMsgId     = $result['value'][0]['id'];
                        $conversationId = $result['value'][0]['conversationId'] ?? null;
                        break;
                    }
                } catch (\Exception) {
                    // lanjut ke fallback berikutnya
                }
            }

            if (!$graphMsgId) {
                Log::warning('StagingTicketController@linkStagingToEmail: pesan tidak ditemukan di Graph', [
                    'staging_id'          => $staging->id,
                    'internet_message_id' => $internetMessageId,
                ]);
                return;
            }

            // Fetch body email untuk ditampilkan di modal validasi
            $emailBodyHtml = null;
            try {
                $msg           = $emailCtrl->graphGetPublic(
                    "/users/{$sender}/messages/{$graphMsgId}",
                    ['$select' => 'body']
                );
                $emailBodyHtml = $msg['body']['content'] ?? null;
            } catch (\Exception $e) {
                Log::warning('StagingTicketController@linkStagingToEmail: gagal fetch body', [
                    'staging_id' => $staging->id,
                    'error'      => $e->getMessage(),
                ]);
            }

            $update = [
                'graph_message_id' => $graphMsgId,
                'email_thread_id'  => $conversationId,
                'email_message_id' => $internetMessageId,
                'channel'          => 'email',
                'has_attachments'  => true,   // Jarvies sudah lampirkan file di emailnya
            ];
            if ($emailBodyHtml) {
                $update['email_body_html'] = $emailBodyHtml;
            }
            $staging->update($update);

            Log::info('StagingTicketController@linkStagingToEmail: berhasil link ke email', [
                'staging_id'          => $staging->id,
                'graph_message_id'    => $graphMsgId,
                'internet_message_id' => $internetMessageId,
            ]);

        } catch (\Exception $e) {
            Log::warning('StagingTicketController@linkStagingToEmail: gagal', [
                'staging_id'          => $staging->id,
                'internet_message_id' => $internetMessageId,
                'error'               => $e->getMessage(),
            ]);
        }
    }

    /**
     * Bangun HTML body untuk email konfirmasi submission ke customer.
     */
    private function buildStagingEmailBody(StagingTicket $staging): string
    {
        $rows = '';
        $rows .= $this->optionalRow('Subject', $staging->description);
        $rows .= $this->optionalRow('Priority', $staging->ticket_priority);
        $rows .= $this->optionalRow('Module', $staging->module);
        $rows .= $this->optionalRow('Client', $staging->client);
        $rows .= $this->optionalRow('Contact', $staging->name);
        $rows .= $this->optionalRow('Phone', $staging->no_hp);

        $table = $rows
            ? "<table style='border-collapse:collapse;width:100%;margin-bottom:16px'>{$rows}</table>"
            : '';

        $bodySection = '';
        if (!empty($staging->body)) {
            $bodySection = "<div style='margin-bottom:16px'><strong>Description:</strong><div style='margin-top:8px;padding:12px;background:#f9f9f9;border:1px solid #e0e0e0;border-radius:4px'>{$staging->body}</div></div>";
        }

        return "
<p>Dear Customer,</p>
<p>Your support ticket has been submitted and is currently under review. Our helpdesk team will process it shortly.</p>
{$table}
{$bodySection}
<p>We will notify you once your ticket has been approved and assigned a ticket number.</p>
<br>
<p>Best Regards,<br><strong>Helpdesk Support</strong></p>
";
    }

    /**
     * Bangun satu baris &lt;tr&gt; tabel untuk email, hanya jika $value tidak kosong.
     */
    private function optionalRow(string $label, ?string $value): string
    {
        if ($value === null || $value === '') {
            return '';
        }
        return "<tr>"
            . "<td style='padding:6px 12px 6px 0;font-weight:600;white-space:nowrap;vertical-align:top;color:#555'>{$label}</td>"
            . "<td style='padding:6px 0'>: " . e($value) . "</td>"
            . "</tr>";
    }

    // ─── Private formatter ────────────────────────────────────────────────────

    /**
     * Siapa boleh benar-benar membaca isi staging_tickets.ai_analysis:
     *   - Customer (bukan employee): TIDAK PERNAH — itu catatan kerja internal
     *     validator (termasuk saran assignee, dugaan akar masalah), bukan
     *     sesuatu yang ditujukan untuk customer baca sendiri.
     *   - Staff internal: boleh, KECUALI staging ticket ini milik customer yang
     *     punya catatan credential tersimpan (CustomerCredential) DAN staff ini
     *     sendiri tidak punya izin 'customer.section.credential.view'.
     *     AiTicketAnalyzerService::resolveCredentialContext() bisa menyerap
     *     catatan credential itu ke dalam ai_analysis berdasarkan izin siapa
     *     pun yang MEMICU analisa-nya (lihat CustomerCredential::contextNotesFor())
     *     — bukan siapa yang MEMBACA hasilnya sekarang. Tanpa gerbang ini,
     *     validator lain yang sebenarnya tidak punya izin credential bisa
     *     membaca cache ai_analysis itu dan diam-diam melihat info credential
     *     lewat jalan belakang.
     *
     * @param array<int, int> $customerIdsWithCredentials customer_id yang PUNYA
     *        baris di customer_credential — dihitung SEKALI per request (lihat
     *        index()/show()), bukan query per baris, supaya tidak N+1.
     */
    private function canViewAiAnalysis(bool $isCustomerViewer, bool $hasCredentialPermission, ?int $customerId, array $customerIdsWithCredentials): bool
    {
        if ($isCustomerViewer) {
            return false;
        }

        if (!$customerId || !in_array($customerId, $customerIdsWithCredentials, true)) {
            return true;
        }

        return $hasCredentialPermission;
    }

    /**
     * @param bool $includeHeavyFields false untuk list (index()) — body/
     *        email_body_html/ai_analysis bisa besar (email lengkap, JSON
     *        analisa AI) dan list cuma menampilkan potongan description
     *        (lihat renderTable() di staging/index.blade.php maupun
     *        staging/rejected.blade.php) — tidak ada baris tabel yang benar-benar
     *        membaca field ini. Detail lengkap tetap diambil terpisah lewat
     *        show() saat validator benar-benar buka satu tiket (openModal()).
     *        true (default) dipakai show()/store() yang memang butuh detail penuh.
     */
    private function formatStaging(
        StagingTicket $s,
        bool $isCustomerViewer = true,
        bool $hasCredentialPermission = false,
        array $customerIdsWithCredentials = [],
        bool $includeHeavyFields = true
    ): array {
        $canViewAi = $includeHeavyFields
            && $this->canViewAiAnalysis($isCustomerViewer, $hasCredentialPermission, $s->customer_id, $customerIdsWithCredentials);

        $customerName = null;
        if ($s->customer) {
            $bd = $s->customer->basicData;
            $customerName = $bd ? trim(($bd->title ?? '') . ' ' . ($bd->name_1 ?? '')) : null;
        }

        $endCustomerName = null;
        if ($s->end_customer_id && $s->relationLoaded('endCustomer') && $s->endCustomer) {
            $bd = $s->endCustomer->basicData;
            $endCustomerName = $bd ? trim(($bd->title ?? '') . ' ' . ($bd->name_1 ?? '')) : null;
        }

        $validatorName = null;
        if ($s->validator) {
            $bd = $s->validator->basicData;
            $validatorName = $bd ? trim(($bd->first_name ?? '') . ' ' . ($bd->last_name ?? '')) : null;
        }

        // Attachments (dari staging_attachments — web/Jarvies uploads)
        $attachments = [];
        if ($s->relationLoaded('attachments')) {
            $attachments = $s->attachments->map(fn ($a) => [
                'id'            => $a->id,
                'original_name' => $a->original_name,
                'file_name'     => $a->file_name,
                'file_size'     => $a->file_size,
                'mime_type'     => $a->mime_type,
                'url'           => $a->public_url,
            ])->toArray();
        }

        return [
            'id'                  => $s->id,
            'customer_id'         => $s->customer_id,
            'customer_name'       => $customerName,
            'end_customer_id'     => $s->end_customer_id,
            'end_customer_name'   => $endCustomerName,
            'submitted_by_email'  => $s->submitted_by_email,
            'sender_name'         => $s->sender_name,
            'cc_emails'           => $s->cc_emails,
            'description'         => $s->description,
            'ticket_priority'     => $s->ticket?->ticket_priority ?? $s->ticket_priority,
            'ticket_type'         => $s->ticket?->ticket_type ?? $s->ticket_type,
            'scale'               => $s->ticket?->scale ?? $s->scale,
            'status'              => $s->status,
            'rejection_reason'    => $s->rejection_reason,
            'channel'             => $s->channel,
            'email_thread_id'     => $s->email_thread_id,
            'has_attachments'     => $s->has_attachments || count($attachments) > 0,
            'graph_message_id'    => $s->graph_message_id,
            'validated_by'        => $s->validated_by,
            'validator_name'      => $validatorName,
            'validated_at'        => $s->validated_at?->toIso8601String(),
            'ticket_id'           => $s->ticket_id,
            'ticket_number'       => $s->ticket?->ticket_number,
            'created_at'          => $s->created_at?->toIso8601String(),
            'updated_at'          => $s->updated_at?->toIso8601String(),
            'attachments'         => $attachments,       // ← file attachments (web uploads)
            // Field tambahan
            'name'                => $s->name,
            'no_hp'               => $s->no_hp,
            'module'              => $s->module,
            'module_id'           => $s->module_id,
            'client'              => $s->client,
        ]
        // Field "berat" (body email lengkap + JSON analisa AI) — cuma disertakan
        // untuk show()/store() yang memang butuh detail penuh satu tiket. List
        // (index()) tidak pernah menampilkan isinya (cuma potongan description),
        // jadi tidak perlu ikut terkirim untuk tiap baris — lihat renderTable()
        // di staging/index.blade.php & staging/rejected.blade.php (keduanya
        // fetch ulang lewat show($id) baru baca field-field ini, via openModal()).
        + ($includeHeavyFields ? [
            'body'            => $s->body,           // ← full message body dari Jarvies/web form
            'email_body_html' => $s->email_body_html,
            // Analisa AI (cache — lihat AiTicketAnalyzerService). Digerbangi
            // canViewAiAnalysis() — lihat docblock method itu. ai_analysis_restricted
            // biar frontend bisa kasih pesan yang jelas ("ada hasil tapi disembunyikan
            // dari Anda"), bukan cuma diam-diam kosong seperti "belum pernah dianalisa".
            'ai_analysis'              => $canViewAi ? $s->ai_analysis : null,
            'ai_analysis_generated_at' => $s->ai_analysis_generated_at?->toIso8601String(),
            'ai_analysis_status'       => $s->ai_analysis_status,
            'ai_analysis_stale'        => $this->isAiAnalysisStale($s),
            'ai_analysis_restricted'   => !$canViewAi && null !== $s->ai_analysis,
        ] : []);
    }

    /**
     * True kalau staging ticket ini diperbarui SETELAH analisis AI-nya dibuat
     * — beda dari AI Summarize (yang auto-invalidate lewat sidik jari isi
     * tiket), analisis AI di sini TIDAK auto-refresh karena panggilan Opus-5
     * + Agent Skill mahal untuk dipicu ulang otomatis tiap kali staging
     * ticket-nya diedit. Ini cukup jadi PERINGATAN pasif buat validator,
     * bukan trigger auto re-analyze.
     *
     * Toleransi 3 detik menyerap selisih mikro-waktu wajar antara
     * ai_analysis_generated_at (di-set eksplisit di
     * AiTicketAnalyzerService::analyze()) dan updated_at (di-set Eloquent
     * otomatis pada UPDATE query yang SAMA) — tanpa ini, hasil yang baru saja
     * selesai dianalisis akan langsung tertandai basi oleh selisih milidetik.
     */
    private function isAiAnalysisStale(StagingTicket $s): bool
    {
        if (!$s->ai_analysis || !$s->ai_analysis_generated_at || !$s->updated_at) {
            return false;
        }

        return $s->updated_at->gt($s->ai_analysis_generated_at->copy()->addSeconds(3));
    }
}
