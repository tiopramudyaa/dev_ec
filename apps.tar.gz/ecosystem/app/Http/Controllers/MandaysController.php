<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Enums\RoleId;
use App\Models\AuditLog;
use App\Models\Notification;
use App\Models\Ticket;
use App\Models\Customer;
use App\Models\CustomerMandays;
use App\Models\CustomerMandaysDetail;
use App\Models\ConsultantMandays;
use App\Models\ConsultantMandaysDetail;
use App\Models\Employee;
use App\Models\EmployeeQualification;
use App\Models\Timesheet;
use App\Models\TicketMessage;

class MandaysController extends Controller
{
    // =========================================================================
    // AUTH HELPERS
    // =========================================================================

    /**
     * Can this employee review/approve Resolution Days regardless of ticket participation?
     * 'ticket.head-mandays' = Head of Support (also grants the ticket-detail review UI).
     * 'ticket.approve-resolution-days' = separate slug for the Resolution Days report list
     * (granted to Admin) — kept distinct so granting it doesn't also surface the
     * Head-only ticket-detail sidebar sections for roles that shouldn't see those.
     */
    private function canReviewResolutionDays(?Employee $employee): bool
    {
        return (bool) ($employee?->canAccessMenu('ticket.head-mandays') || $employee?->canAccessMenu('ticket.approve-resolution-days'));
    }

    /** Return 403 if session user is not a PIC or member of $ticket. Head-level permission bypasses this check. */
    private function denyUnlessParticipant(Ticket $ticket, string $msg = 'You are not a participant of this ticket.'): ?\Illuminate\Http\JsonResponse
    {
        $empId = session('user')['id'] ?? null;

        if (!$empId) {
            return response()->json(['success' => false, 'message' => 'Unauthenticated.'], 401);
        }

        $employee = Employee::find($empId);

        // Users with head-level mandays permission bypass the participant check
        if ($employee?->canAccessMenu('ticket.head-mandays')) return null;

        $isPic    = (int) $ticket->ticket_lead_id === (int) $empId;
        $isMember = $ticket->members()->where('ticket_member.employee_id', $empId)->exists();

        if (!$isPic && !$isMember) {
            return response()->json(['success' => false, 'message' => $msg], 403);
        }

        return null;
    }

    /**
     * For Change Request tickets, only the ticket's team lead (not other members) may
     * propose Customer Mandays. Head-level permission bypasses this check.
     */
    private function denyUnlessTeamLeadForChangeRequest(Ticket $ticket): ?\Illuminate\Http\JsonResponse
    {
        if ($ticket->ticket_type !== 'Change Request') return null;

        $empId = session('user')['id'] ?? null;
        $employee = Employee::find($empId);

        if ($employee?->canAccessMenu('ticket.head-mandays')) return null;

        if ((int) $ticket->ticket_lead_id !== (int) $empId) {
            return response()->json([
                'success' => false,
                'message' => 'For Change Request tickets, only the team lead can propose customer mandays.',
            ], 403);
        }

        return null;
    }

    /** Return 403 if session user is neither a ticket participant nor has head-level mandays permission. */
    private function denyUnlessParticipantOrHead(Ticket $ticket, string $msg = 'You do not have access to this proposal.'): ?\Illuminate\Http\JsonResponse
    {
        $empId = session('user')['id'] ?? null;

        if (!$empId) {
            return response()->json(['success' => false, 'message' => 'Unauthenticated.'], 401);
        }

        $employee = Employee::find($empId);

        if ($this->canReviewResolutionDays($employee)) return null;

        $isPic    = (int) $ticket->ticket_lead_id === (int) $empId;
        $isMember = $ticket->members()->where('ticket_member.employee_id', $empId)->exists();

        if (!$isPic && !$isMember) {
            return response()->json(['success' => false, 'message' => $msg], 403);
        }

        return null;
    }

    // =========================================================================
    // SHARED UTILITY
    // =========================================================================

    /**
     * GET /api/tickets/{ticketId}/mandays/modules
     * Modul aktif dari kualifikasi lead + member ticket.
     */
    public function getModules($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        // Kumpulkan employee IDs: lead + active members
        $employeeIds = collect();

        if ($ticket->ticket_lead_id) {
            $employeeIds->push($ticket->ticket_lead_id);
        }

        $memberIds = $ticket->members()->pluck('ticket_member.employee_id');
        $employeeIds = $employeeIds->merge($memberIds)->unique()->filter()->values();

        // Ambil module aktif yang ada di kualifikasi lead/member
        $modules = \App\Models\Module::whereHas('qualifications', function ($q) use ($employeeIds) {
                $q->whereIn('employee_id', $employeeIds);
            })
            ->where('is_active', true)
            ->orderBy('name')
            ->get(['id', 'name']);

        return response()->json(['success' => true, 'data' => $modules]);
    }

    // =========================================================================
    // CUSTOMER MANDAYS — PIC ENDPOINTS
    // =========================================================================

    /**
     * GET /api/tickets/{ticketId}/mandays/pic-draft
     * Ambil draft/proposal terbaru customer mandays untuk PIC.
     */
    public function getCustomerDraft($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->latestVersion()
            ->with(['details', 'canceledBy.basicData'])
            ->first();

        return response()->json([
            'success'                 => true,
            'data'                    => $proposal ? $this->formatCustomerProposal($proposal) : null,
            'ticket_mandays_status'   => $ticket->mandays_proposal_status ?? 'none',
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/pic-draft
     * PIC simpan/update draft.
     */
    public function saveCustomerDraft(Request $request, $ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipant($ticket, 'Only the ticket PIC or a member can edit the customer mandays draft.')) {
            return $deny;
        }

        if ($deny = $this->denyUnlessTeamLeadForChangeRequest($ticket)) {
            return $deny;
        }

        $sessionUser = session('user');
        $employeeId  = $sessionUser['id'] ?? null;

        $request->validate([
            'details'           => 'required|array|min:1',
            'details.*.activity'=> 'nullable|string',
            'details.*.module'  => 'required|string|max:100',
            'details.*.mandays' => 'required|numeric|min:0',
            'description'       => 'required|string|max:255',
            'proposal_notes'    => 'nullable|string|max:2000',
        ]);

        $existing = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        // Blokir edit saat sedang dalam proses (pending_helpdesk / sent_to_chat)
        if ($existing && in_array($existing->status, ['pending_helpdesk', 'sent_to_chat'])) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot edit while proposal is being reviewed.',
            ], 422);
        }

        $total = collect($request->details)->sum('mandays');
        if ($total <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'Total mandays harus lebih dari 0. Isi minimal satu nilai mandays.',
            ], 422);
        }

        DB::beginTransaction();
        try {
            if (!$existing || in_array($existing->status, ['canceled', 'approved'])) {
                // Buat versi baru
                $latestVersion = CustomerMandays::where('ticket_id', $ticketId)->max('version') ?? 0;
                $proposal = CustomerMandays::create([
                    'ticket_id'           => $ticketId,
                    'version'             => $latestVersion + 1,
                    'description'         => $request->description ?: null,
                    'proposal_notes'      => $request->proposal_notes ?: null,
                    'proposed_by_agent_id'=> $employeeId,
                    'proposed_at'         => now(),
                    'status'              => 'draft',
                    'total_mandays'       => $total,
                ]);
            } else {
                // Update existing draft
                $proposal = $existing;
                $proposal->update([
                    'description'    => $request->description ?: $proposal->description,
                    'proposal_notes' => $request->has('proposal_notes') ? ($request->proposal_notes ?: null) : $proposal->proposal_notes,
                    'total_mandays'  => $total,
                    'proposed_at'    => now(),
                ]);
                $proposal->details()->delete();
            }

            foreach ($request->details as $d) {
                if (($d['mandays'] ?? 0) > 0) {
                    CustomerMandaysDetail::create([
                        'customer_mandays_id' => $proposal->id,
                        'activity'            => $d['activity'] ?? null,
                        'module'              => $d['module'],
                        'mandays'             => $d['mandays'],
                    ]);
                }
            }

            $ticket->update(['mandays_proposal_status' => 'pic_draft']);

            DB::commit();

            return response()->json([
                'success'               => true,
                'message'               => 'Draft saved.',
                'data'                  => $this->formatCustomerProposal($proposal->fresh(['details'])),
                'ticket_mandays_status' => 'pic_draft',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('saveCustomerDraft error', ['e' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Failed to save the customer mandays draft. Please try again.'], 500);
        }
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/pic-draft/submit
     * PIC submit ke Helpdesk.
     */
    public function submitCustomerDraft($ticketId)
    {
        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipant($ticket, 'Only the ticket PIC or a member can submit the customer mandays proposal.')) {
            return $deny;
        }

        if ($deny = $this->denyUnlessTeamLeadForChangeRequest($ticket)) {
            return $deny;
        }

        $proposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        if (!$proposal || $proposal->status !== 'draft') {
            return response()->json(['success' => false, 'message' => 'No draft to submit.'], 422);
        }

        $proposal->update([
            'status'                  => 'pending_helpdesk',
            'submitted_to_customer_at'=> now(),
        ]);
        $ticket->update(['mandays_proposal_status' => 'pending_helpdesk']);

        $sessionUser = session('user');
        $fromName    = $sessionUser['name'] ?? 'PIC';
        $fromId      = $sessionUser['id'] ?? null;
        $ticketNum   = $ticket->ticket_number ?? $ticketId;
        $this->notifyRoles(
            [RoleId::DELIVERY_HELPDESK->value],
            'customer_mandays_proposed',
            $fromName,
            $fromId,
            "Ticket #{$ticketNum} — Customer mandays proposal submitted for review",
            "/ticket/{$ticketId}"
        );

        return response()->json([
            'success'               => true,
            'message'               => 'Proposal submitted to Helpdesk.',
            'ticket_mandays_status' => 'pending_helpdesk',
        ]);
    }

    /**
     * DELETE /api/tickets/{ticketId}/mandays/pic-draft
     * PIC hapus draft (hanya boleh selama status masih draft, belum disubmit).
     */
    public function deleteCustomerDraft($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipant($ticket, 'Only the ticket PIC or a member can delete the customer mandays draft.')) {
            return $deny;
        }

        if ($deny = $this->denyUnlessTeamLeadForChangeRequest($ticket)) {
            return $deny;
        }

        $proposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        if (!$proposal || $proposal->status !== 'draft') {
            return response()->json(['success' => false, 'message' => 'No draft to delete.'], 422);
        }

        DB::beginTransaction();
        try {
            $proposal->details()->delete();
            $proposal->delete();

            // If an earlier (canceled/approved) version still exists, that version
            // becomes latest again — reflect its status instead of wiping history.
            $previous = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();
            $newStatus = $previous ? ($previous->status === 'draft' ? 'pic_draft' : $previous->status) : 'none';
            $ticket->update(['mandays_proposal_status' => $newStatus]);

            DB::commit();

            return response()->json([
                'success'               => true,
                'message'               => 'Draft deleted.',
                'ticket_mandays_status' => $newStatus,
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('deleteCustomerDraft error', ['e' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Failed to delete the customer mandays draft. Please try again.'], 500);
        }
    }

    // =========================================================================
    // CUSTOMER MANDAYS — HELPDESK ENDPOINTS
    // =========================================================================

    /**
     * GET /api/tickets/{ticketId}/mandays/hd-draft
     * Helpdesk ambil proposal terbaru untuk direview.
     */
    public function getHelpdeskDraft($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->latestVersion()
            ->with(['details', 'canceledBy.basicData', 'proposedByAgent.basicData'])
            ->first();

        return response()->json([
            'success'               => true,
            'data'                  => $proposal ? $this->formatCustomerProposal($proposal) : null,
            'ticket_mandays_status' => $ticket->mandays_proposal_status ?? 'none',
        ]);
    }

    /**
     * PUT /api/tickets/{ticketId}/mandays/hd-draft
     * Helpdesk edit detail proposal.
     */
    public function saveHelpdeskDraft(Request $request, $ticketId)
    {
        $sessionUserId = session('user')['id'] ?? null;
        $employee = $sessionUserId ? Employee::find($sessionUserId) : null;
        if (!$employee?->canAccessMenu('ticket.review-mandays')) {
            return response()->json(['success' => false, 'message' => 'You do not have permission to edit the customer mandays proposal.'], 403);
        }

        $request->validate([
            'details'           => 'required|array|min:1',
            'details.*.activity'=> 'nullable|string',
            'details.*.module'  => 'required|string|max:100',
            'details.*.mandays' => 'required|numeric|min:0',
            'description'       => 'nullable|string|max:255',
            'proposal_notes'    => 'nullable|string|max:2000',
        ]);

        $proposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        if (!$proposal || !in_array($proposal->status, ['pending_helpdesk', 'sent_to_chat'])) {
            return response()->json(['success' => false, 'message' => 'No proposal to edit.'], 422);
        }

        $total = collect($request->details)->sum('mandays');

        $canEditActivity = $employee?->canAccessMenu('ticket.review-mandays.edit-activity');

        // Load original activity names sebelum di-delete (untuk preserve jika tidak ada permission)
        // Key: module → activity (jika modul sama di banyak activity, pakai yang pertama)
        $origActivityByModule = $canEditActivity
            ? []
            : $proposal->details()->get()->groupBy('module')->map(fn($rows) => $rows->first()->activity)->toArray();

        $proposal->details()->delete();
        foreach ($request->details as $d) {
            if (($d['mandays'] ?? 0) > 0) {
                $activityName = $canEditActivity
                    ? ($d['activity'] ?? null)
                    : ($origActivityByModule[$d['module']] ?? $d['activity'] ?? null);
                CustomerMandaysDetail::create([
                    'customer_mandays_id' => $proposal->id,
                    'activity'            => $activityName,
                    'module'              => $d['module'],
                    'mandays'             => $d['mandays'],
                ]);
            }
        }

        $updateData = ['total_mandays' => $total];
        if ($request->has('description') && $employee?->canAccessMenu('ticket.review-mandays.edit-description')) {
            $updateData['description'] = $request->description ?: null;
        }
        if ($request->has('proposal_notes') && $employee?->canAccessMenu('ticket.review-mandays.edit-proposal-notes')) {
            $updateData['proposal_notes'] = $request->proposal_notes ?: null;
        }

        $proposal->update($updateData);

        return response()->json([
            'success' => true,
            'message' => 'Helpdesk draft updated.',
            'data'    => $this->formatCustomerProposal($proposal->fresh(['details'])),
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/hd-draft/submit-chat
     * Helpdesk kirim ke chat customer via email.
     */
    public function submitToChat($ticketId)
    {
        $sessionUserId = session('user')['id'] ?? null;
        $employee = $sessionUserId ? Employee::find($sessionUserId) : null;
        if (!$employee?->canAccessMenu('ticket.review-mandays.send-to-customer')) {
            return response()->json(['success' => false, 'message' => 'You do not have permission to send the proposal to the customer.'], 403);
        }

        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();
        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->latestVersion()
            ->with('details')
            ->first();

        if (!$proposal || $proposal->status !== 'pending_helpdesk') {
            return response()->json(['success' => false, 'message' => 'Proposal is not in pending_helpdesk status.'], 422);
        }

        $sessionUser = session('user');
        $senderName  = $sessionUser['name'] ?? 'Helpdesk Support';
        $senderId    = $sessionUser['id'] ?? null;

        // Update status terlebih dahulu (bersihkan rejection_reason jika re-send setelah ditolak customer)
        $proposal->update([
            'status'           => 'sent_to_chat',
            'sent_to_chat_at'  => now(),
            'rejection_reason' => null,
            'customer_notes'   => null,
        ]);
        $ticket->update(['mandays_proposal_status' => 'sent_to_chat']);

        // Selalu buat TicketMessage terlebih dahulu agar proposal tampil di chat
        $htmlBody  = $this->buildMandaysEmailHtml($proposal, $ticket, $senderName);
        $plainText = 'Mandays proposal sent to customer. Total: ' . $this->fmtMd((float) $proposal->total_mandays) . ' mandays.';

        $ticketMsg = TicketMessage::create([
            'ticket_id'           => $ticketId,
            'sender_type'         => 'employee',
            'sender_id'           => $senderId,
            'sender_name'         => $senderName,
            'message'             => $plainText,
            'message_html'        => $htmlBody,
            'is_internal_note'    => false,
            'channel'             => 'web',
            'is_read_by_customer' => false,
            'is_read_by_agent'    => true,
        ]);

        $ticket->update([
            'last_message_at'     => now(),
            'last_agent_reply_at' => now(),
        ]);

        // Coba kirim email ke customer (non-fatal jika gagal — pesan sudah tersimpan di chat)
        $emailSent    = false;
        $emailWarning = null;
        $emailTo      = null;

        try {
            // Resolve primary TO dan additional TO dari ticket.to_emails (dipersist setiap reply).
            // Jika to_emails tidak ada, fallback ke resolveCustomerEmailForTicket().
            $ticketToEmails = array_values(array_filter(
                is_array($ticket->to_emails) ? $ticket->to_emails : [],
                fn($e) => is_string($e) && $e !== ''
            ));
            if (!empty($ticketToEmails)) {
                $customerEmail = $ticketToEmails[0];
                $additionalTo  = array_slice($ticketToEmails, 1);
            } else {
                $customerEmail = $this->resolveCustomerEmailForTicket($ticket);
                $additionalTo  = [];
            }

            if (!$customerEmail) {
                $emailWarning = 'No customer email address found. Proposal saved to chat only.';
                Log::warning('MandaysController@submitToChat: no customer email', ['ticket_id' => $ticketId]);
            } else {
                $emailTo = $customerEmail;

                $lastEmailMsg = TicketMessage::where('ticket_id', $ticketId)
                    ->where('channel', 'email')
                    ->whereNotNull('email_message_id')
                    ->orderBy('created_at', 'desc')
                    ->first();
                $inReplyTo = $lastEmailMsg?->email_message_id;

                $subject = '[JARVIES] #' . $ticket->ticket_number . ' : ' . mb_substr($ticket->description ?? '', 0, 80);

                // CC: prioritaskan ticket.cc_emails, fallback ke pesan pertama dengan CC.
                $rawTicketCc = $ticket->cc_emails;
                $ccList = $rawTicketCc
                    ? (is_array($rawTicketCc) ? $rawTicketCc : (json_decode($rawTicketCc, true) ?? []))
                    : [];
                if (empty($ccList)) {
                    $firstMsgWithCc = TicketMessage::where('ticket_id', $ticketId)
                        ->whereNotNull('cc_emails')
                        ->orderBy('created_at', 'asc')
                        ->first();
                    $rawMsgCc = $firstMsgWithCc?->cc_emails;
                    $ccList = $rawMsgCc
                        ? (is_array($rawMsgCc) ? $rawMsgCc : (json_decode($rawMsgCc, true) ?? []))
                        : [];
                }

                $result = app(EmailController::class)->sendTicketReply(
                    $customerEmail,
                    $subject,
                    $htmlBody,
                    $inReplyTo,
                    [],
                    $ccList,
                    true,
                    $ticket->email_thread_id ?? null,
                    false,
                    [],
                    $additionalTo
                );

                // Update message channel dan email_message_id setelah email berhasil terkirim
                $ticketMsg->update([
                    'channel'          => 'email',
                    'email_message_id' => $result['internet_message_id'] ?? null,
                ]);

                // Selalu sync email_thread_id ke conversationId terbaru
                if (!empty($result['conversation_id']) && $result['conversation_id'] !== $ticket->email_thread_id) {
                    $ticket->update(['email_thread_id' => $result['conversation_id']]);
                }

                $emailSent = true;
                Log::info('MandaysController@submitToChat: email sent', [
                    'ticket_id'    => $ticketId,
                    'to'           => $customerEmail,
                    'additional'   => $additionalTo,
                    'cc_count'     => count($ccList),
                ]);
            }
        } catch (\Throwable $e) {
            $emailWarning = 'Proposal saved to chat but email could not be sent.';
            Log::error('MandaysController@submitToChat: email failed', [
                'ticket_id' => $ticketId,
                'error'     => $e->getMessage(),
                'error_at'  => $e->getFile() . ':' . $e->getLine(),
            ]);
        }

        return response()->json([
            'success'               => true,
            'message'               => $emailSent
                ? 'Proposal sent to customer via email.'
                : ($emailWarning ?? 'Status updated.'),
            'email_sent'            => $emailSent,
            'email_warning'         => $emailWarning,
            'email_to'              => $emailTo,
            'ticket_mandays_status' => 'sent_to_chat',
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/hd-draft/approve
     * Helpdesk approve → update man_days ticket.
     */
    public function approveCustomerMandays($ticketId)
    {
        $sessionUserId = session('user')['id'] ?? null;
        $employee = $sessionUserId ? Employee::find($sessionUserId) : null;
        if (!$employee?->canAccessMenu('ticket.review-mandays.approve')) {
            return response()->json(['success' => false, 'message' => 'You do not have permission to approve the customer mandays proposal.'], 403);
        }

        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();
        $proposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        // Sending to the customer chat is no longer required before approving —
        // Helpdesk can approve directly from pending_helpdesk, or from sent_to_chat
        // if it was sent anyway.
        if (!$proposal || !in_array($proposal->status, ['pending_helpdesk', 'sent_to_chat'])) {
            return response()->json(['success' => false, 'message' => 'No proposal ready to approve.'], 422);
        }

        $proposal->update(['status' => 'approved']);
        $ticket->update([
            'mandays_proposal_status' => 'approved',
            'man_days'                => $proposal->total_mandays,
        ]);

        return response()->json([
            'success'               => true,
            'message'               => 'Customer mandays approved.',
            'ticket_mandays_status' => 'approved',
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/hd-draft/cancel
     * Helpdesk cancel proposal (with optional notes for PIC).
     */
    public function cancelCustomerMandays(Request $request, $ticketId)
    {
        $sessionUserId = session('user')['id'] ?? null;
        $employee = $sessionUserId ? Employee::find($sessionUserId) : null;
        if (!$employee?->canAccessMenu('ticket.review-mandays.cancel')) {
            return response()->json(['success' => false, 'message' => 'You do not have permission to cancel the customer mandays proposal.'], 403);
        }

        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        $latestProposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();

        // Target a specific (possibly already-superseded) version via mandays_id, or
        // default to the latest version — covers both "cancel the current draft/
        // pending proposal" and "cancel an older version a newer one has since
        // superseded" (that older version, since it's superseded, is always already
        // 'approved' — a version only gets superseded once the prior one was
        // approved or canceled).
        $mandaysId = $request->input('mandays_id');
        $proposal  = $mandaysId
            ? CustomerMandays::where('ticket_id', $ticketId)->where('id', $mandaysId)->first()
            : $latestProposal;

        if (!$proposal || !in_array($proposal->status, ['pending_helpdesk', 'sent_to_chat', 'approved'])) {
            return response()->json(['success' => false, 'message' => 'No active proposal to cancel.'], 422);
        }

        $isLatest = $latestProposal && $proposal->id === $latestProposal->id;

        // Cancelling an already-approved proposal reverses something the customer
        // already signed off on (approval happens on their side via JARVIES) — gated
        // behind a separate permission on top of the base cancel permission. Also
        // required whenever a non-latest version is targeted, since that version is
        // always already-approved by definition. No automated customer notification
        // here by design; Helpdesk follows up by email manually.
        if (($proposal->status === 'approved' || !$isLatest) && !$employee->canAccessMenu('ticket.review-mandays.cancel-approved')) {
            return response()->json(['success' => false, 'message' => 'You do not have permission to cancel an already-approved proposal.'], 403);
        }

        $cancelNotes    = $request->input('cancel_notes');
        $sessionUser    = session('user');
        $canceledById   = $sessionUser['id'] ?? null;

        $proposal->update([
            'status'          => 'canceled',
            'notes'           => $cancelNotes ?: null,
            'canceled_by_id'  => $canceledById,
            'canceled_at'     => now(),
        ]);

        // ticket.mandays_proposal_status mirrors the LATEST version's status only —
        // cancelling an older, already-superseded version must not overwrite it with
        // a stale 'canceled' while the actual latest version is still active/approved.
        if ($isLatest) {
            $ticket->update(['mandays_proposal_status' => 'canceled']);
        }

        // Notify PIC and all members
        $fromName  = $sessionUser['name'] ?? 'Helpdesk';
        $ticketNum = $ticket->ticket_number ?? $ticketId;
        $versionNote = !$isLatest ? " (Version {$proposal->version})" : '';
        $preview   = "Ticket #{$ticketNum} — Customer mandays proposal{$versionNote} has been canceled"
                   . ($cancelNotes ? ': ' . mb_substr($cancelNotes, 0, 80) : '');
        $link      = "/ticket/{$ticketId}";

        $recipients = collect();
        if ($ticket->ticket_lead_id) {
            $recipients->push($ticket->ticket_lead_id);
        }
        $ticket->members->pluck('employee_id')->each(fn ($id) => $recipients->push($id));

        $recipients->unique()->each(function ($empId) use ($canceledById, $fromName, $preview, $link) {
            Notification::create([
                'employee_id'      => $empId,
                'type'             => 'customer_mandays_canceled',
                'from_employee_id' => $canceledById,
                'from_name'        => $fromName,
                'preview'          => $preview,
                'link'             => $link,
                'is_read'          => false,
            ]);
        });

        return response()->json([
            'success'               => true,
            'message'               => 'Proposal canceled.',
            'ticket_mandays_status' => 'canceled',
        ]);
    }

    // =========================================================================
    // RESOLUTION MANDAYS — PIC + HEAD OF SUPPORT
    // =========================================================================

    /**
     * GET /api/tickets/{ticketId}/mandays/resolution
     * Ambil proposal resolution + daftar orang.
     */
    public function getResolutionProposal($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipantOrHead($ticket, 'Only ticket participants or Delivery Support Head can view the resolution days proposal.')) {
            return $deny;
        }

        $proposal = ConsultantMandays::where('ticket_id', $ticketId)
            ->latestPerTicket()
            ->with(['details.employee.basicData', 'proposedByAgent.basicData', 'approvedByHead.basicData'])
            ->first();

        // Bangun people list: PIC + Members aktif + Past Members
        $people = $this->buildPeopleList($ticket, $proposal);

        $internalStatus = $ticket->resolution_days_status ?? 'none';

        return response()->json([
            'success'                 => true,
            'data'                    => $proposal ? $this->formatResolutionProposal($proposal) : null,
            'resolution_days_status' => $internalStatus,
            'customer_mandays_status' => $ticket->mandays_proposal_status ?? 'none',
            'people'                  => $people,
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/internal
     * PIC simpan/update draft internal.
     */
    public function saveResolutionProposal(Request $request, $ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipant($ticket, 'Only the ticket PIC or a member can save the resolution days proposal.')) {
            return $deny;
        }

        $sessionUser = session('user');
        $employeeId  = $sessionUser['id'] ?? null;

        $validator = Validator::make($request->all(), [
            'details'                      => 'required|array|min:1',
            'details.*.employee_id'        => 'required|integer',
            'details.*.module'             => 'nullable|string|max:100',
            'details.*.mandays'            => 'required|numeric|min:0',
            'details.*.additional_mandays' => 'nullable|numeric|min:0',
            'details.*.notes'              => 'nullable|string|max:500',
            'notes'                        => 'nullable|string|max:1000',
        ]);

        // Jika additional_mandays diisi (> 0) maka notes wajib diisi
        $validator->after(function ($v) use ($request) {
            foreach ($request->input('details', []) as $i => $detail) {
                $add = (float) ($detail['additional_mandays'] ?? 0);
                if ($add > 0 && empty(trim($detail['notes'] ?? ''))) {
                    $v->errors()->add(
                        "details.{$i}.notes",
                        'Notes are required if Additional MD is filled.'
                    );
                }
            }
        });

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->first(),
                'errors'  => $validator->errors(),
            ], 422);
        }

        $existing = ConsultantMandays::where('ticket_id', $ticketId)->latestPerTicket()->first();

        // Snapshot details before transaction for change-detection
        $preDetails  = $existing ? $existing->details()->get()->keyBy('employee_id') : collect();
        $dataChanged = !$existing || $this->resolutionDataChanged($existing, $preDetails, $request);

        DB::beginTransaction();
        try {
            $total = collect($request->details)->sum('mandays');

            if (!$existing) {
                $proposal = ConsultantMandays::create([
                    'ticket_id'            => $ticketId,
                    'proposed_by_agent_id' => $employeeId,
                    'proposed_at'          => now(),
                    'last_edited_at'       => now(),
                    'status'               => 'draft',
                    'helpdesk_notes'       => $request->notes,
                    'total_mandays'        => $total,
                ]);
            } else {
                $proposal = $existing;
                // PIC can keep refining the proposal while it's pending Head approval —
                // status stays pending_head so it's still visible in the Head's queue
                // without needing to resubmit. An already-approved proposal that gets
                // edited falls back to draft (needs re-approval); draft/needs_revision/
                // rejected also (re)fall to draft on edit as before.
                $keepStatus = $existing->status === 'pending_approval'
                    || (!$dataChanged && $existing->status === 'approved');
                $proposal->update([
                    'status'           => $keepStatus ? $existing->status : 'draft',
                    'last_edited_at'   => now(),
                    'helpdesk_notes'   => $request->notes,
                    'total_mandays'    => $total,
                    'rejection_reason' => $dataChanged ? null : $existing->rejection_reason,
                ]);
            }

            // Preserve progress: load existing detail rows keyed by employee_id
            $existingDetails = $proposal->details()->get()->keyBy('employee_id');
            $newEmployeeIds  = collect($request->details)->pluck('employee_id')->map('intval')->toArray();

            // Hapus hanya row yang tidak ada di request baru
            $proposal->details()->whereNotIn('employee_id', $newEmployeeIds)->delete();

            foreach ($request->details as $d) {
                if (($d['mandays'] ?? 0) > 0 || ($d['additional_mandays'] ?? 0) > 0) {
                    $empId          = (int) $d['employee_id'];
                    $existingDetail = $existingDetails->get($empId);

                    if ($existingDetail) {
                        // Update mandays saja — progress_percentage/progress_note tetap
                        $existingDetail->update([
                            'module'             => $d['module'] ?? null,
                            'mandays'            => $d['mandays'] ?? 0,
                            'additional_mandays' => $d['additional_mandays'] ?? 0,
                            'notes'              => $d['notes'] ?? null,
                        ]);
                    } else {
                        ConsultantMandaysDetail::create([
                            'consultant_mandays_id' => $proposal->id,
                            'employee_id'           => $empId,
                            'module'                => $d['module'] ?? null,
                            'mandays'               => $d['mandays'] ?? 0,
                            'additional_mandays'    => $d['additional_mandays'] ?? 0,
                            'approved_additional'   => 0,
                            'notes'                 => $d['notes'] ?? null,
                        ]);
                    }
                }
            }

            // Map proposal status → ticket resolution_days_status
            $ticketStatus = match($proposal->status) {
                'pending_approval' => 'pending_head',
                'approved'         => 'approved',
                default            => 'draft',
            };
            $ticket->update(['resolution_days_status' => $ticketStatus]);

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('saveResolutionProposal error', ['e' => $e->getMessage(), 'error_at' => $e->getFile() . ':' . $e->getLine()]);
            return response()->json(['success' => false, 'message' => 'Failed to save the resolution days proposal. Please try again.'], 500);
        }

        $message = match (true) {
            !$dataChanged                       => 'Saved. No changes detected.',
            $ticketStatus === 'pending_head'    => 'Updated — still pending Head approval, no need to resubmit.',
            default                              => 'Draft saved. Submit to Head Support for approval.',
        };

        return response()->json([
            'success'                 => true,
            'message'                 => $message,
            'data'                    => $this->formatResolutionProposal($proposal->fresh(['details.employee.basicData', 'proposedByAgent.basicData', 'approvedByHead.basicData'])),
            'resolution_days_status' => $ticketStatus,
            'data_changed'            => $dataChanged,
        ]);
    }

    private function resolutionDataChanged(
        ConsultantMandays $existing,
        \Illuminate\Support\Collection $existingDetails,
        Request $request
    ): bool {
        if (trim($existing->helpdesk_notes ?? '') !== trim($request->notes ?? '')) {
            return true;
        }

        $newDetails = collect($request->details)->filter(
            fn ($d) => ($d['mandays'] ?? 0) > 0 || ($d['additional_mandays'] ?? 0) > 0
        );

        if ($existingDetails->count() !== $newDetails->count()) {
            return true;
        }

        foreach ($newDetails as $d) {
            $empId = (int) $d['employee_id'];
            $old   = $existingDetails->get($empId);
            if (!$old) return true;
            if ((float) $old->mandays !== (float) ($d['mandays'] ?? 0)) return true;
            if ((float) $old->additional_mandays !== (float) ($d['additional_mandays'] ?? 0)) return true;
            if (trim($old->notes ?? '') !== trim($d['notes'] ?? '')) return true;
        }

        return false;
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/internal/submit
     * PIC submit ke Head of Support.
     */
    public function submitResolutionProposal($ticketId)
    {
        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        if ($deny = $this->denyUnlessParticipant($ticket, 'Only the ticket PIC or a member can submit the resolution days proposal.')) {
            return $deny;
        }

        // Resolution Days can be drafted freely, but on Change Request tickets, submitting
        // to Head requires the Customer Mandays proposal to already be approved by Helpdesk
        // first — customer's own approval is not required at this point, only Helpdesk's.
        // Other ticket types keep the original unrestricted flow.
        if ($ticket->ticket_type === 'Change Request') {
            $customerProposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();
            if (!$customerProposal || $customerProposal->status !== 'approved') {
                return response()->json([
                    'success' => false,
                    'message' => 'Customer Mandays proposal must be approved by Helpdesk before submitting Resolution Days.',
                ], 422);
            }
        }

        $proposal = ConsultantMandays::where('ticket_id', $ticketId)->latestPerTicket()->first();

        if (!$proposal || !in_array($proposal->status, ['draft', 'needs_revision', 'rejected', 'approved'])) {
            return response()->json(['success' => false, 'message' => 'No draft to submit.'], 422);
        }

        $proposal->update(['status' => 'pending_approval', 'proposed_at' => now()]);
        $ticket->update(['resolution_days_status' => 'pending_head']);

        $sessionUser = session('user');
        $fromName    = $sessionUser['name'] ?? 'PIC';
        $fromId      = $sessionUser['id'] ?? null;
        $ticketNum   = $ticket->ticket_number ?? $ticketId;
        $this->notifyRoles(
            [RoleId::DELIVERY_SUPPORT_HEAD->value, RoleId::DELIVERY_PROJECT_HEAD->value],
            'resolution_days_proposed',
            $fromName,
            $fromId,
            "Ticket #{$ticketNum} — Resolution days proposal submitted for your review",
            "/ticket/{$ticketId}"
        );

        return response()->json([
            'success'                 => true,
            'message'                 => 'Internal proposal submitted to Delivery Support Head.',
            'resolution_days_status' => 'pending_head',
        ]);
    }

    /**
     * POST /api/tickets/{ticketId}/mandays/internal/approve
     * Head of Support approve.
     */
    public function approveResolutionProposal(Request $request, $ticketId)
    {
        $sessionUserId = session('user')['id'] ?? null;
        $employee = $sessionUserId ? Employee::find($sessionUserId) : null;
        if (!$this->canReviewResolutionDays($employee)) {
            return response()->json(['success' => false, 'message' => 'Only Head of Support or Admin can approve resolution days proposals.'], 403);
        }

        // approved_details is required (not just nullable) — Approved Days is a per-employee
        // judgment call the Head must actually make, so approval can't go through with no
        // numbers submitted at all (mirrors the "must be filled" check on the review modal).
        $request->validate([
            'approved_details'                      => 'required|array|min:1',
            'approved_details.*.employee_id'        => 'required|integer',
            'approved_details.*.approved_mandays'   => 'required|numeric|min:0',
            'approved_details.*.approved_additional'=> 'required|numeric|min:0',
            'confirm_negative'                      => 'sometimes|boolean',
        ]);

        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();
        $proposal = ConsultantMandays::where('ticket_id', $ticketId)->latestPerTicket()->first();
        $sessionUser = session('user');
        $headId   = $sessionUser['id'] ?? null;

        // Head of support dapat menyimpan additional mandays dari status apapun kecuali belum ada proposal
        $saveable = ['draft', 'pending_approval', 'needs_revision', 'approved'];
        if (!$proposal || !in_array($proposal->status, $saveable)) {
            return response()->json(['success' => false, 'message' => 'No proposal to save.'], 422);
        }

        // On Change Request tickets only: Head can only approve Resolution Days once the
        // Customer Mandays proposal has been approved — either by the customer via chat,
        // or directly by Helpdesk. Team lead can keep editing the resolution proposal
        // freely up until this point (saveResolutionProposal has no status gate), this
        // only blocks the final Head approval action.
        if ($ticket->ticket_type === 'Change Request') {
            $customerProposal = CustomerMandays::where('ticket_id', $ticketId)->latestVersion()->first();
            if (!$customerProposal || $customerProposal->status !== 'approved') {
                return response()->json([
                    'success' => false,
                    'message' => 'Customer Mandays proposal must be approved before Resolution Days can be approved.',
                ], 422);
            }
        }

        // PIC can keep editing this proposal right up until approval (see
        // saveResolutionProposal()), so the numbers Head is about to lock in here may
        // already have outpaced what employees logged. Warn before finalizing —
        // require an explicit confirm_negative=true resend to proceed anyway.
        if (!$request->boolean('confirm_negative')) {
            $warnings = $this->findNegativeRemainingWarnings($ticket, $proposal, $request->input('approved_details', []));
            if (!empty($warnings)) {
                return response()->json([
                    'success'               => false,
                    'requires_confirmation' => true,
                    'message'               => 'Some employees will have negative remaining MD with these numbers.',
                    'warnings'              => $warnings,
                ], 422);
            }
        }

        // Snapshot "before" approved_mandays/approved_additional for every detail about to be
        // touched. The update below is an Eloquent mass update via query builder
        // ($proposal->details()->where(...)->update(...)) — Laravel never fires model events
        // for that (only single-instance $model->save() does), so AuditObserver (wired via
        // ConsultantMandaysDetail's Auditable trait) never sees it. This is the actual
        // approved-mandays billing number, so it's logged manually below once the
        // transaction has committed.
        $touchedEmployeeIds  = collect($request->approved_details)->pluck('employee_id')->map(fn ($id) => (int) $id);
        $detailsBeforeUpdate = $proposal->details()
            ->with('employee.basicData')
            ->whereIn('employee_id', $touchedEmployeeIds)
            ->get()
            ->keyBy(fn ($d) => (int) $d->employee_id);

        DB::beginTransaction();
        try {
            // Update approved_mandays + approved_additional per employee
            if (!empty($request->approved_details)) {
                foreach ($request->approved_details as $ad) {
                    $proposal->details()
                        ->where('employee_id', $ad['employee_id'])
                        ->update([
                            'approved_mandays'    => $ad['approved_mandays'],
                            'approved_additional' => $ad['approved_additional'],
                        ]);
                }
            }

            // Recalculate total_mandays = sum(approved_mandays + approved_additional).
            // Note: this total_mandays / ticket.man_days reflects what Head actually approved
            // here. It intentionally does NOT feed the MD-quota checks used elsewhere (e.g.
            // TimesheetController submit validation), which still read the raw `mandays`
            // column directly and are unaffected by this value.
            $total = $proposal->details()->get()->sum(fn($d) => (float) ($d->approved_mandays ?? 0) + $d->approved_additional);

            $proposal->update([
                'status'              => 'approved',
                'approved_by_head_id' => $headId,
                'approved_at'         => now(),
                'total_mandays'       => $total,
            ]);
            $ticket->update([
                'resolution_days_status' => 'approved',
                'man_days'                => $total,
            ]);

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('approveResolutionProposal error', ['e' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Failed to approve the resolution days proposal. Please try again.'], 500);
        }

        // Audit trail: one row per employee whose approved_mandays/approved_additional was
        // just locked in — recordAction() is fire-and-forget, so a logging hiccup here can
        // never affect the approval that already committed above.
        foreach ($request->approved_details as $ad) {
            $beforeDetail = $detailsBeforeUpdate->get((int) $ad['employee_id']);
            if (!$beforeDetail) {
                continue; // employee_id isn't part of this proposal's details — the update above was a no-op
            }

            $employeeName = trim(
                ($beforeDetail->employee?->basicData?->first_name ?? '') . ' ' . ($beforeDetail->employee?->basicData?->last_name ?? '')
            );
            $employeeLabel = $employeeName !== '' ? $employeeName : "Employee #{$ad['employee_id']}";

            AuditLog::recordAction(
                module: 'Mandays', // matches ConsultantMandaysDetail::$auditModule so these rows group together
                auditableType: 'ConsultantMandaysDetail',
                auditableId: $beforeDetail->id,
                event: 'updated',
                recordLabel: $employeeLabel,
                description: "approved Consultant Mandays Detail: {$ad['approved_mandays']} MD for {$employeeLabel}",
                old: [
                    'approved_mandays'    => $beforeDetail->approved_mandays,
                    'approved_additional' => $beforeDetail->approved_additional,
                ],
                new: [
                    'approved_mandays'    => $ad['approved_mandays'],
                    'approved_additional' => $ad['approved_additional'],
                ],
            );
        }

        return response()->json([
            'success'                 => true,
            'message'                 => 'Internal proposal approved.',
            'resolution_days_status' => 'approved',
            'total_mandays'           => $total,
        ]);
    }

    /**
     * Per employee in the proposal being approved, compare the quota that would take
     * effect (the approved_mandays + approved_additional Head is about to save) against
     * what they've already logged (draft/submitted/approved timesheets on this ticket).
     * Returns one entry per employee whose remaining would go negative.
     */
    private function findNegativeRemainingWarnings(Ticket $ticket, ConsultantMandays $proposal, array $approvedDetails): array
    {
        $approvedAdditionalMap = collect($approvedDetails)->keyBy('employee_id');
        $details = $proposal->details()->with('employee.basicData')->get();

        // Sum consumed mandays for every consultant on this proposal in one
        // query instead of one Timesheet::sum() per consultant.
        $consumedMap = Timesheet::where('ticket_id', $ticket->ticket_id)
            ->whereIn('employee_id', $details->pluck('employee_id'))
            ->whereIn('status', ['draft', 'submitted', 'approved'])
            ->groupBy('employee_id')
            ->selectRaw('employee_id, SUM(md_consumed) as total')
            ->pluck('total', 'employee_id');

        $warnings = [];
        foreach ($details as $detail) {
            $incoming            = $approvedAdditionalMap->get($detail->employee_id);
            $approvedMandays     = (float) ($incoming['approved_mandays'] ?? $detail->approved_mandays ?? 0);
            $approvedAdditional  = (float) ($incoming['approved_additional'] ?? $detail->approved_additional ?? 0);
            $quota = round($approvedMandays + $approvedAdditional, 2);

            $consumed = (float) ($consumedMap->get($detail->employee_id) ?? 0);

            $remaining = round($quota - $consumed, 2);
            if ($remaining < 0) {
                $name = trim(($detail->employee?->basicData?->first_name ?? '') . ' ' . ($detail->employee?->basicData?->last_name ?? ''));
                $warnings[] = [
                    'employee_id'   => $detail->employee_id,
                    'employee_name' => $name ?: "Employee #{$detail->employee_id}",
                    'quota'         => $quota,
                    'consumed'      => $consumed,
                    'remaining'     => $remaining,
                ];
            }
        }

        return $warnings;
    }

    // =========================================================================
    // JARVIES CUSTOMER ENDPOINTS (accessed via API Key, no session)
    // =========================================================================

    /**
     * GET /api/jarvies/tickets/{ticketId}/mandays/customer
     * Ambil proposal aktif yang terlihat oleh customer.
     */
    public function customerMandaysForJarvies($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        // Hanya tampilkan jika proposal sudah sampai ke customer
        $visibleStatuses = ['sent_to_chat', 'approved', 'canceled'];

        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->whereIn('status', $visibleStatuses)
            ->latestVersion()
            ->with('details')
            ->first();

        $ticketStatus = $ticket->mandays_proposal_status ?? 'none';
        $visible = $proposal !== null;

        if (!$visible) {
            return response()->json([
                'success'                => true,
                'visible'                => false,
                'mandays_proposal_status'=> $ticketStatus,
                'proposal'               => null,
            ]);
        }

        // Build grid Activity × Module
        $activities = [];
        $modules    = [];
        $grid       = [];
        foreach ($proposal->details as $d) {
            $act = $d->activity ?? 'General';
            if (!in_array($act, $activities)) $activities[] = $act;
            if (!in_array($d->module, $modules)) $modules[] = $d->module;
            $grid[$act][$d->module] = ($grid[$act][$d->module] ?? 0) + (float) $d->mandays;
        }
        sort($modules);

        $columnTotals = [];
        foreach ($modules as $mod) {
            $columnTotals[$mod] = array_sum(array_column(array_map(fn($actVals) => [$actVals[$mod] ?? 0], $grid), 0));
        }
        // Recompute column totals properly
        $columnTotals = [];
        foreach ($modules as $mod) {
            $total = 0;
            foreach ($grid as $actVals) {
                $total += $actVals[$mod] ?? 0;
            }
            $columnTotals[$mod] = $total;
        }

        return response()->json([
            'success'                => true,
            'visible'                => true,
            'mandays_proposal_status'=> $ticketStatus,
            'proposal'               => [
                'id'                   => $proposal->id,
                'version'              => $proposal->version,
                'status'               => $proposal->status,
                'total_mandays'        => (float) $proposal->total_mandays,
                'notes'                => $proposal->notes,
                'customer_notes'       => $proposal->customer_notes,
                'proposed_at'          => $proposal->proposed_at?->toISOString(),
                'customer_response_at' => $proposal->customer_response_at?->toISOString(),
            ],
            'activities'             => $activities,
            'modules'                => $modules,
            'grid'                   => $grid,
            'column_totals'          => $columnTotals,
        ]);
    }

    /**
     * POST /api/jarvies/tickets/{ticketId}/mandays/customer/approve
     * Customer approve proposal.
     */
    public function customerApproveMandays($ticketId)
    {
        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();
        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->where('status', 'sent_to_chat')
            ->latestVersion()
            ->first();

        if (!$proposal) {
            return response()->json(['success' => false, 'message' => 'No active proposal to approve.'], 422);
        }

        $proposal->update([
            'status'               => 'approved',
            'customer_response_at' => now(),
        ]);
        $ticket->update([
            'mandays_proposal_status' => 'approved',
            'man_days'                => $proposal->total_mandays,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Proposal approved.',
            'mandays_proposal_status' => 'approved',
        ]);
    }

    /**
     * POST /api/jarvies/tickets/{ticketId}/mandays/customer/reject
     * Customer reject proposal dengan alasan.
     */
    public function customerRejectMandays(Request $request, $ticketId)
    {
        $request->validate([
            'reason' => 'nullable|string|max:1000',
        ]);

        $ticket   = Ticket::where('ticket_id', $ticketId)->firstOrFail();
        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->where('status', 'sent_to_chat')
            ->latestVersion()
            ->first();

        if (!$proposal) {
            return response()->json(['success' => false, 'message' => 'No active proposal to reject.'], 422);
        }

        $reason = $request->input('reason') ?: null;

        $proposal->update([
            'status'               => 'pending_helpdesk',
            'rejection_reason'     => $reason,
            'customer_notes'       => $reason,
            'customer_response_at' => now(),
        ]);
        $ticket->update(['mandays_proposal_status' => 'pending_helpdesk']);

        return response()->json([
            'success' => true,
            'message' => 'Proposal rejected.',
            'mandays_proposal_status' => 'pending_helpdesk',
        ]);
    }

    // =========================================================================
    // PRIVATE HELPERS
    // =========================================================================

    /**
     * GET /api/tickets/{ticketId}/mandays/history
     * Seluruh versi propose customer mandays untuk satu tiket (ringkasan, tanpa details).
     */
    public function getCustomerMandaysHistory($ticketId)
    {
        $ticket = Ticket::where('ticket_id', $ticketId)->firstOrFail();

        $versions = CustomerMandays::where('ticket_id', $ticketId)
            ->orderBy('version', 'asc')
            ->get()
            ->map(fn($p) => [
                'id'             => $p->id,
                'version'        => $p->version,
                'description'    => $p->description,
                'proposal_notes' => $p->proposal_notes,
                'status'         => $p->status,
                'total_mandays'  => (float) $p->total_mandays,
                'last_update'    => ($p->updated_at ?? $p->proposed_at)?->toISOString(),
            ]);

        return response()->json([
            'success'               => true,
            'data'                  => $versions,
            'ticket_mandays_status' => $ticket->mandays_proposal_status ?? 'none',
        ]);
    }

    /**
     * GET /api/tickets/{ticketId}/consultant-mandays/approved
     * Returns the latest approved consultant (internal) mandays total for a ticket.
     * Used by the timesheet modal to auto-fill Jatah MD.
     */
    public function getApprovedConsultantMandays($ticketId)
    {
        $approved = ConsultantMandays::where('ticket_id', $ticketId)
            ->where('status', 'approved')
            ->orderBy('approved_at', 'desc')
            ->first();

        return response()->json([
            'success' => true,
            'data'    => $approved ? [
                'total_mandays' => (float) $approved->total_mandays,
                'approved_at'   => $approved->approved_at?->toISOString(),
            ] : null,
        ]);
    }

    /**
     * GET /api/tickets/{ticketId}/mandays/approved
     * Returns the latest approved customer mandays total for a ticket.
     */
    public function getApprovedMandays($ticketId)
    {
        $approved = CustomerMandays::where('ticket_id', $ticketId)
            ->where('status', 'approved')
            ->orderBy('version', 'desc')
            ->first();

        return response()->json([
            'success'       => true,
            'data'          => $approved ? [
                'total_mandays' => (float) $approved->total_mandays,
                'version'       => $approved->version,
            ] : null,
        ]);
    }

    /**
     * GET /api/tickets/{ticketId}/mandays/version/{mandaysId}
     * Detail lengkap satu versi propose customer mandays (read-only, untuk semua role).
     */
    public function getCustomerMandaysVersionDetail($ticketId, $mandaysId)
    {
        $proposal = CustomerMandays::where('ticket_id', $ticketId)
            ->where('id', $mandaysId)
            ->with(['details', 'canceledBy.basicData', 'proposedByAgent.basicData'])
            ->firstOrFail();

        return response()->json([
            'success' => true,
            'data'    => $this->formatCustomerProposal($proposal),
        ]);
    }

    private function formatCustomerProposal(CustomerMandays $p): array
    {
        $canceledBy = $p->canceledBy?->basicData;
        $canceledByName = $canceledBy
            ? trim(($canceledBy->first_name ?? '') . ' ' . ($canceledBy->last_name ?? ''))
            : null;

        $proposedBy = $p->proposedByAgent?->basicData;
        $proposedByName = $proposedBy
            ? trim(($proposedBy->first_name ?? '') . ' ' . ($proposedBy->last_name ?? ''))
            : null;

        return [
            'id'                   => $p->id,
            'version'              => $p->version,
            'description'          => $p->description,
            'proposal_notes'       => $p->proposal_notes,
            'status'               => $p->status,
            'total_mandays'        => (float) $p->total_mandays,
            'cancel_notes'         => $p->notes,
            'canceled_by_name'     => $canceledByName,
            'canceled_at'          => $p->canceled_at?->toISOString(),
            'proposed_by_name'     => $proposedByName,
            'rejection_reason'     => $p->rejection_reason,
            'customer_notes'       => $p->customer_notes,
            'proposed_at'          => $p->proposed_at?->toISOString(),
            'sent_to_chat_at'      => $p->sent_to_chat_at?->toISOString(),
            'customer_response_at' => $p->customer_response_at?->toISOString(),
            'last_update'          => ($p->updated_at ?? $p->proposed_at)?->toISOString(),
            'details'              => $p->details->map(fn($d) => [
                'id'       => $d->id,
                'activity' => $d->activity,
                'module'   => $d->module,
                'mandays'  => (float) $d->mandays,
            ])->values()->all(),
        ];
    }

    private function formatResolutionProposal(ConsultantMandays $p): array
    {
        return [
            'id'               => $p->id,
            'status'           => $p->status,
            'notes'            => $p->helpdesk_notes,
            'rejection_reason' => $p->rejection_reason,
            'total_mandays'    => (float) $p->total_mandays,
            'proposed_by'      => $p->proposedByAgent?->basicData?->first_name
                                 . ' ' . $p->proposedByAgent?->basicData?->last_name,
            'approved_by_head' => $p->approvedByHead
                                 ? ($p->approvedByHead->basicData?->first_name . ' ' . $p->approvedByHead->basicData?->last_name)
                                 : null,
            'approved_at'      => $p->approved_at?->toISOString(),
            'details'          => $p->details->map(fn($d) => [
                'id'                  => $d->id,
                'employee_id'         => $d->employee_id,
                'employee_name'       => $d->employee?->basicData?->first_name . ' ' . $d->employee?->basicData?->last_name,
                'module'              => $d->module,
                'mandays'             => (float) $d->mandays,
                'approved_mandays'    => (float) ($d->approved_mandays ?? 0),
                'additional_mandays'  => (float) ($d->additional_mandays ?? 0),
                'approved_additional' => (float) ($d->approved_additional ?? 0),
                'notes'               => $d->notes,
            ])->values()->all(),
        ];
    }

    private function buildPeopleList(Ticket $ticket, ?ConsultantMandays $proposal): array
    {
        $people = [];

        // PIC
        if ($ticket->ticket_lead_id) {
            $pic = Employee::with(['basicData', 'qualifications'])->find($ticket->ticket_lead_id);
            if ($pic) {
                $people[$ticket->ticket_lead_id] = [
                    'employee_id' => $ticket->ticket_lead_id,
                    'name'        => trim(($pic->basicData?->first_name ?? '') . ' ' . ($pic->basicData?->last_name ?? '')),
                    'role'        => 'PIC',
                    'modules'     => $pic->qualifications->pluck('module')->filter()->unique()->values()->all(),
                ];
            }
        }

        // Active members
        $members = $ticket->members()->with(['basicData', 'qualifications'])->get();
        foreach ($members as $m) {
            if (!isset($people[$m->employee_id])) {
                $people[$m->employee_id] = [
                    'employee_id' => $m->employee_id,
                    'name'        => trim(($m->basicData?->first_name ?? '') . ' ' . ($m->basicData?->last_name ?? '')),
                    'role'        => 'Member',
                    'modules'     => $m->qualifications->pluck('module')->filter()->unique()->values()->all(),
                ];
            }
        }

        // Past members from consultant_mandays_detail history
        if ($proposal) {
            $pastIds = ConsultantMandaysDetail::where('consultant_mandays_id', $proposal->id)
                ->pluck('employee_id')
                ->unique();
            $missingIds = $pastIds->reject(fn($empId) => isset($people[$empId]));
            if ($missingIds->isNotEmpty()) {
                $pastEmployees = Employee::with(['basicData', 'qualifications'])
                    ->whereIn('employee_id', $missingIds)
                    ->get()
                    ->keyBy('employee_id');
                foreach ($missingIds as $empId) {
                    $emp = $pastEmployees->get($empId);
                    if ($emp) {
                        $people[$empId] = [
                            'employee_id' => $empId,
                            'name'        => trim(($emp->basicData?->first_name ?? '') . ' ' . ($emp->basicData?->last_name ?? '')),
                            'role'        => 'Past Member',
                            'modules'     => $emp->qualifications->pluck('module')->filter()->unique()->values()->all(),
                        ];
                    }
                }
            }
        }

        return array_values($people);
    }

    private function notifyRoles(array $roleIds, string $type, string $fromName, ?int $fromId, string $preview, string $link): void
    {
        try {
            Employee::withAnyRole($roleIds)
                ->where('is_active', true)
                ->pluck('employee_id')
                ->each(function ($empId) use ($type, $fromName, $fromId, $preview, $link) {
                    Notification::create([
                        'employee_id'      => $empId,
                        'type'             => $type,
                        'from_employee_id' => $fromId,
                        'from_name'        => $fromName,
                        'preview'          => $preview,
                        'link'             => $link,
                        'is_read'          => false,
                    ]);
                });
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('MandaysController::notifyRoles failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Resolve email customer dari ticket (mirror resolveCustomerEmail di TicketMessageController).
     */
    private function resolveCustomerEmailForTicket(Ticket $ticket): ?string
    {
        if (!empty($ticket->submitted_by_email)) {
            return $ticket->submitted_by_email;
        }

        $submittedEmail = DB::table('staging_tickets')
            ->where('ticket_id', $ticket->ticket_id)
            ->whereNotNull('submitted_by_email')
            ->value('submitted_by_email');
        if ($submittedEmail) return $submittedEmail;

        $firstMsg = TicketMessage::where('ticket_id', $ticket->ticket_id)
            ->where('sender_type', 'customer')
            ->whereNotNull('sender_email')
            ->orderBy('created_at', 'asc')
            ->first();
        if ($firstMsg?->sender_email) return $firstMsg->sender_email;

        if ($ticket->customer_id) {
            return Customer::find($ticket->customer_id)?->email;
        }

        return null;
    }

    /**
     * Format mandays value — up to 2 decimal places, trailing zeros stripped.
     * 0.25 → "0.25", 0.5 → "0.5", 1.0 → "1"
     */
    private function fmtMd(float $val): string
    {
        return rtrim(rtrim(number_format($val, 2, '.', ''), '0'), '.');
    }

    /**
     * Build HTML email body untuk mandays proposal yang dikirim ke customer.
     */
    private function buildMandaysEmailHtml(CustomerMandays $proposal, Ticket $ticket, string $agentName): string
    {
        $ticketNum = htmlspecialchars($ticket->ticket_number ?? '', ENT_QUOTES, 'UTF-8');
        $agent     = htmlspecialchars($agentName, ENT_QUOTES, 'UTF-8');
        $version   = $proposal->version ?? 1;
        $total     = $this->fmtMd((float) $proposal->total_mandays);
        $notes     = $proposal->notes ? '<p style="margin:8px 0;font-size:13px;color:#444;">' . nl2br(htmlspecialchars($proposal->notes, ENT_QUOTES, 'UTF-8')) . '</p>' : '';

        // Bangun kolom modul unik
        $modules = $proposal->details->pluck('module')->unique()->sort()->values()->all();

        // Bangun matrix: activity → module → total mandays
        $matrix = [];
        foreach ($proposal->details as $d) {
            $act = $d->activity ?: 'General';
            $matrix[$act][$d->module] = ($matrix[$act][$d->module] ?? 0) + (float) $d->mandays;
        }

        // Header kolom tabel
        $headerCols = '';
        foreach ($modules as $mod) {
            $headerCols .= '<th style="padding:8px 12px;border:1px solid #ddd;background:#8b1a1a;color:#fff;white-space:nowrap;">' . htmlspecialchars($mod, ENT_QUOTES, 'UTF-8') . '</th>';
        }

        // Baris data
        $rows = '';
        $moduleTotals = array_fill_keys($modules, 0);
        foreach ($matrix as $act => $modValues) {
            $rows .= '<tr>';
            $rows .= '<td style="padding:7px 12px;border:1px solid #ddd;font-weight:600;">' . htmlspecialchars($act, ENT_QUOTES, 'UTF-8') . '</td>';
            foreach ($modules as $mod) {
                $val = $modValues[$mod] ?? 0;
                $moduleTotals[$mod] += $val;
                $rows .= '<td style="padding:7px 12px;border:1px solid #ddd;text-align:center;">' . ($val > 0 ? $this->fmtMd($val) : '-') . '</td>';
            }
            $rows .= '</tr>';
        }

        // Baris total
        $totalCols = '';
        foreach ($modules as $mod) {
            $totalCols .= '<td style="padding:7px 12px;border:1px solid #ddd;text-align:center;font-weight:bold;">' . $this->fmtMd($moduleTotals[$mod]) . '</td>';
        }

        return <<<HTML
        <table width="100%" cellpadding="0" cellspacing="0" border="0"
               style="font-family:Arial,Helvetica,sans-serif;max-width:650px;border-collapse:collapse;">
            <tr>
                <td style="background-color:#8b1a1a;padding:16px 24px;border-radius:6px 6px 0 0;">
                    <p style="color:#ffffff;font-size:16px;font-weight:bold;margin:0;">PT Eclectic Consulting</p>
                    <p style="color:rgba(255,255,255,0.75);font-size:11px;margin:3px 0 0 0;">Helpdesk Support &nbsp;&middot;&nbsp; Ticket #{$ticketNum}</p>
                </td>
            </tr>
            <tr>
                <td style="padding:20px 24px;background:#fff;border:1px solid #e5e7eb;border-top:none;">
                    <p style="margin:0 0 12px;font-size:14px;color:#222;">Yth. Bapak/Ibu,</p>
                    <p style="margin:0 0 16px;font-size:13px;color:#444;line-height:1.6;">
                        Berikut kami sampaikan proposal <strong>Man Days</strong> untuk Ticket <strong>#{$ticketNum}</strong>
                        (Versi {$version}). Mohon konfirmasi persetujuan Anda.
                    </p>
                    {$notes}
                    <div style="overflow-x:auto;margin:16px 0;">
                        <table cellpadding="0" cellspacing="0" border="0"
                               style="border-collapse:collapse;font-size:13px;min-width:100%;">
                            <thead>
                                <tr>
                                    <th style="padding:8px 12px;border:1px solid #ddd;background:#8b1a1a;color:#fff;text-align:left;">Activity</th>
                                    {$headerCols}
                                </tr>
                            </thead>
                            <tbody>
                                {$rows}
                            </tbody>
                            <tfoot>
                                <tr style="background:#f9f9f9;">
                                    <td style="padding:7px 12px;border:1px solid #ddd;font-weight:bold;">Total</td>
                                    {$totalCols}
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <p style="margin:16px 0 4px;font-size:13px;color:#444;">
                        <strong>Total Man Days: {$total}</strong>
                    </p>
                    <p style="margin:16px 0 0;font-size:12px;color:#666;">
                        Please contact us if you have any questions regarding this proposal.
                    </p>
                </td>
            </tr>
            <tr>
                <td style="padding:12px 24px;background:#f3f4f6;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 6px 6px;">
                    <p style="margin:0;font-size:11px;color:#6b7280;">
                        Sent by: <strong>{$agent}</strong> &nbsp;&middot;&nbsp; PT Eclectic Consulting Helpdesk
                    </p>
                </td>
            </tr>
        </table>
        HTML;
    }
}
