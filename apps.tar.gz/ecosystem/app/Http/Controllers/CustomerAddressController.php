<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class CustomerAddressController extends Controller
{
    /**
     * Human-readable label for an address row, used by audit log entries.
     */
    private function addressLabel($city, $street, $addressId): string
    {
        $label = trim(collect([$city, $street])->filter()->implode(', '));

        return $label !== '' ? $label : "Address #{$addressId}";
    }

    /**
     * Sync customer.email dari alamat pertama yang punya email.
     * Dipanggil setelah create/update/delete alamat.
     *
     * PENTING: bersifat non-destruktif. customer.email adalah "Company Email"
     * yang bisa di-set mandiri lewat form Create Customer atau import (kolom
     * "Email"). Kalau tidak ada satu pun alamat yang punya email, JANGAN
     * mengosongkan customer.email — kalau tidak, sekadar edit/hapus alamat akan
     * menghapus Company Email yang diimport (hilang dari list & header).
     */
    private function syncCustomerEmail(int $customerId): void
    {
        $email = DB::table('customer_address')
            ->where('customer_id', $customerId)
            ->whereNotNull('email')
            ->where('email', '!=', '')
            ->orderBy('address_id', 'asc')
            ->value('email');

        // Hanya update bila ada email alamat yang ditemukan; jika tidak,
        // pertahankan Company Email yang sudah ada.
        if ($email) {
            DB::table('customer')
                ->where('customer_id', $customerId)
                ->update(['email' => $email]);
        }
    }

    /**
     * Get all addresses for a customer
     */
    public function index($customerId)
    {
        try {
            Log::info('=== API: FETCHING CUSTOMER ADDRESSES ===', [
                'customer_id' => $customerId
            ]);

            $addresses = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->orderBy('address_id', 'desc')
                ->get();

            Log::info('=== API: CUSTOMER ADDRESSES FETCHED SUCCESSFULLY ===', [
                'count' => $addresses->count()
            ]);

            return response()->json([
                'success' => true,
                'data' => $addresses
            ]);

        } catch (\Exception $e) {
            Log::error('=== API: ERROR FETCHING CUSTOMER ADDRESSES ===', [
                'error' => $e->getMessage(),
                'error_at' => $e->getFile() . ':' . $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch addresses'
            ], 500);
        }
    }

    /**
     * Get single address
     */
    public function show($customerId, $addressId)
    {
        try {
            Log::info('=== API: FETCHING CUSTOMER ADDRESS ===', [
                'customer_id' => $customerId,
                'address_id' => $addressId
            ]);

            $address = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->where('address_id', $addressId)
                ->first();

            if (!$address) {
                return response()->json([
                    'success' => false,
                    'message' => 'Address not found'
                ], 404);
            }

            Log::info('=== API: CUSTOMER ADDRESS FETCHED SUCCESSFULLY ===');

            return response()->json([
                'success' => true,
                'data' => $address
            ]);

        } catch (\Exception $e) {
            Log::error('=== API: ERROR FETCHING CUSTOMER ADDRESS ===', [
                'error' => $e->getMessage(),
                'error_at' => $e->getFile() . ':' . $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch address'
            ], 500);
        }
    }

    /**
     * Store new address
     */
    public function store(Request $request, $customerId)
    {
        Log::info('=== API: CREATING CUSTOMER ADDRESS ===', [
            'customer_id' => $customerId,
            'data' => $request->all()
        ]);

        $validator = Validator::make($request->all(), [
            'address_type' => 'nullable|string|max:50',
            'country' => 'nullable|string|max:100',
            'region' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'district' => 'nullable|string|max:100',
            'rural_urban_village' => 'nullable|string|max:100',
            'street' => 'nullable|string|max:255',
            'house_number' => 'nullable|string|max:50',
            'building_name' => 'nullable|string|max:255',
            'full_address' => 'nullable|string',
            'postal_code' => 'nullable|string|max:20',
            'language' => 'nullable|string|max:50',
            'cell_phone_country' => 'nullable|string|max:10',
            'telephone_country' => 'nullable|string|max:10',
            'fax_country' => 'nullable|string|max:10',
            'email' => 'nullable|email|max:255',
            'website' => 'nullable|url|max:255',
            'preferred_communication' => 'nullable|string|max:50',
            'cell_phone' => 'nullable|string|max:50',
            'telephone' => 'nullable|string|max:50',
            'fax' => 'nullable|string|max:50',
            'telephone_extension' => 'nullable|string|max:10',
            'fax_extension' => 'nullable|string|max:10',
            'valid_from' => 'nullable|date',
            'valid_to' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Check if customer exists
            $customerExists = DB::table('customer')->where('customer_id', $customerId)->exists();
            if (!$customerExists) {
                return response()->json([
                    'success' => false,
                    'message' => 'Customer not found'
                ], 404);
            }

            $addressData = [
                'customer_id' => $customerId,
                'address_type' => $request->address_type,
                'country' => $request->country,
                'region' => $request->region,
                'city' => $request->city,
                'district' => $request->district,
                'rural_urban_village' => $request->rural_urban_village,
                'street' => $request->street,
                'house_number' => $request->house_number,
                'building_name' => $request->building_name,
                'full_address' => $request->full_address,
                'postal_code' => $request->postal_code,
                'language' => $request->language,
                'cell_phone_country' => $request->cell_phone_country,
                'telephone_country' => $request->telephone_country,
                'fax_country' => $request->fax_country,
                'email' => $request->email,
                'website' => $request->website,
                'preferred_communication' => $request->preferred_communication,
                'cell_phone' => $request->cell_phone,
                'telephone' => $request->telephone,
                'fax' => $request->fax,
                'telephone_extension' => $request->telephone_extension,
                'fax_extension' => $request->fax_extension,
                'valid_from' => $request->valid_from,
                'valid_to' => $request->valid_to,
                'created_at' => now(),
                'updated_at' => now(),
            ];

            $addressId = DB::table('customer_address')->insertGetId($addressData);

            $this->syncCustomerEmail((int) $customerId);

            $label = $this->addressLabel($request->city, $request->street, $addressId);

            AuditLog::recordAction(
                module: 'Customer', // matches CustomerAddress's own $auditModule so these rows group together
                auditableType: 'CustomerAddress',
                auditableId: $addressId,
                event: 'created',
                recordLabel: $label,
                description: "added Customer Address: {$label} — Customer #{$customerId}",
                old: null,
                new: $addressData,
            );

            Log::info('=== API: CUSTOMER ADDRESS CREATED SUCCESSFULLY ===', [
                'address_id' => $addressId
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Address created successfully',
                'data' => ['address_id' => $addressId]
            ], 201);

        } catch (\Exception $e) {
            Log::error('=== API: ERROR CREATING CUSTOMER ADDRESS ===', [
                'error' => $e->getMessage(),
                'error_at' => $e->getFile() . ':' . $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to create address'
            ], 500);
        }
    }

    /**
     * Update address
     */
    public function update(Request $request, $customerId, $addressId)
    {
        Log::info('=== API: UPDATING CUSTOMER ADDRESS ===', [
            'customer_id' => $customerId,
            'address_id' => $addressId,
            'data' => $request->all()
        ]);

        $validator = Validator::make($request->all(), [
            'address_type' => 'nullable|string|max:50',
            'country' => 'nullable|string|max:100',
            'region' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'district' => 'nullable|string|max:100',
            'rural_urban_village' => 'nullable|string|max:100',
            'street' => 'nullable|string|max:255',
            'house_number' => 'nullable|string|max:50',
            'building_name' => 'nullable|string|max:255',
            'full_address' => 'nullable|string',
            'postal_code' => 'nullable|string|max:20',
            'language' => 'nullable|string|max:50',
            'cell_phone_country' => 'nullable|string|max:10',
            'telephone_country' => 'nullable|string|max:10',
            'fax_country' => 'nullable|string|max:10',
            'email' => 'nullable|email|max:255',
            'website' => 'nullable|url|max:255',
            'preferred_communication' => 'nullable|string|max:50',
            'cell_phone' => 'nullable|string|max:50',
            'telephone' => 'nullable|string|max:50',
            'fax' => 'nullable|string|max:50',
            'telephone_extension' => 'nullable|string|max:10',
            'fax_extension' => 'nullable|string|max:10',
            'valid_from' => 'nullable|date',
            'valid_to' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Snapshot before update — needed for the audit log entry below.
            $existingAddress = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->where('address_id', $addressId)
                ->first();

            $updateData = [
                'address_type' => $request->address_type,
                'country' => $request->country,
                'region' => $request->region,
                'city' => $request->city,
                'district' => $request->district,
                'rural_urban_village' => $request->rural_urban_village,
                'street' => $request->street,
                'house_number' => $request->house_number,
                'building_name' => $request->building_name,
                'full_address' => $request->full_address,
                'postal_code' => $request->postal_code,
                'language' => $request->language,
                'cell_phone_country' => $request->cell_phone_country,
                'telephone_country' => $request->telephone_country,
                'fax_country' => $request->fax_country,
                'email' => $request->email,
                'website' => $request->website,
                'preferred_communication' => $request->preferred_communication,
                'cell_phone' => $request->cell_phone,
                'telephone' => $request->telephone,
                'fax' => $request->fax,
                'telephone_extension' => $request->telephone_extension,
                'fax_extension' => $request->fax_extension,
                'valid_from' => $request->valid_from,
                'valid_to' => $request->valid_to,
                'updated_at' => now(),
            ];

            $updated = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->where('address_id', $addressId)
                ->update($updateData);

            if ($updated === 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Address not found'
                ], 404);
            }

            $this->syncCustomerEmail((int) $customerId);

            $label = $this->addressLabel($request->city, $request->street, $addressId);

            AuditLog::recordAction(
                module: 'Customer', // matches CustomerAddress's own $auditModule so these rows group together
                auditableType: 'CustomerAddress',
                auditableId: $addressId,
                event: 'updated',
                recordLabel: $label,
                description: "updated Customer Address: {$label} — Customer #{$customerId}",
                old: (array) $existingAddress,
                new: $updateData,
            );

            Log::info('=== API: CUSTOMER ADDRESS UPDATED SUCCESSFULLY ===');

            return response()->json([
                'success' => true,
                'message' => 'Address updated successfully'
            ]);

        } catch (\Exception $e) {
            Log::error('=== API: ERROR UPDATING CUSTOMER ADDRESS ===', [
                'error' => $e->getMessage(),
                'error_at' => $e->getFile() . ':' . $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to update address'
            ], 500);
        }
    }

    /**
     * Delete address
     */
    public function destroy($customerId, $addressId)
    {
        Log::info('=== API: DELETING CUSTOMER ADDRESS ===', [
            'customer_id' => $customerId,
            'address_id' => $addressId
        ]);

        try {
            // Snapshot before delete — needed for the audit log entry below.
            $existingAddress = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->where('address_id', $addressId)
                ->first();

            $deleted = DB::table('customer_address')
                ->where('customer_id', $customerId)
                ->where('address_id', $addressId)
                ->delete();

            if ($deleted === 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Address not found'
                ], 404);
            }

            $this->syncCustomerEmail((int) $customerId);

            $label = $this->addressLabel($existingAddress->city ?? null, $existingAddress->street ?? null, $addressId);

            AuditLog::recordAction(
                module: 'Customer', // matches CustomerAddress's own $auditModule so these rows group together
                auditableType: 'CustomerAddress',
                auditableId: $addressId,
                event: 'deleted',
                recordLabel: $label,
                description: "deleted Customer Address: {$label} — Customer #{$customerId}",
                old: (array) $existingAddress,
                new: null,
            );

            Log::info('=== API: CUSTOMER ADDRESS DELETED SUCCESSFULLY ===');

            return response()->json([
                'success' => true,
                'message' => 'Address deleted successfully'
            ]);

        } catch (\Exception $e) {
            Log::error('=== API: ERROR DELETING CUSTOMER ADDRESS ===', [
                'error' => $e->getMessage(),
                'error_at' => $e->getFile() . ':' . $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to delete address'
            ], 500);
        }
    }
}