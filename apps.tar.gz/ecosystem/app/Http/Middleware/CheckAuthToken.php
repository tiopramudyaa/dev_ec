<?php

namespace App\Http\Middleware;

use App\Http\Controllers\AuthController;
use App\Support\IntendedUrl;
use App\Services\TwoFactorAuthService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class CheckAuthToken
{
    public function handle(Request $request, Closure $next): Response
    {
        // ── 1. Session masih valid (jalur normal) ────────────────────────────
        if (session()->has('auth_token')) {
            $this->hydratePreferences($request);
            return $next($request);
        }

        // ── 2. Session expired — coba restore via remember-me cookie ─────────
        $rememberCookie = $request->cookie(AuthController::REMEMBER_COOKIE);

        if ($rememberCookie) {
            $restored = $this->tryRestoreSession($request, $rememberCookie);
            if ($restored) {
                return $next($request);
            }

            // Cookie ada tapi tidak valid — bersihkan
            $expired = cookie(AuthController::REMEMBER_COOKIE, '', -1);
        }

        // ── 3. Tidak ada session dan tidak ada cookie valid ───────────────────
        if ($request->expectsJson() || $request->is('api/*')) {
            $response = response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);

            if (isset($expired)) {
                $response->withCookie($expired);
            }

            return $response;
        }

        // Simpan URL tujuan supaya setelah login user kembali ke halaman yang
        // ia klik (mis. deep link /ticket/123 dari kartu Teams), bukan dashboard.
        // Dikirim dua jalur: session (rapi) + query ?redirect= (tahan bila cookie
        // session belum/tidak terbawa saat link dibuka dari aplikasi lain).
        $intended = null;
        if ($request->isMethod('GET') && !$request->ajax()) {
            $intended = IntendedUrl::remember($request->fullUrl(), $request);
        }

        $loginUrl = route('login');
        if ($intended !== null) {
            $loginUrl .= '?' . http_build_query([IntendedUrl::QUERY_KEY => $intended]);
        }

        $redirect = redirect()->to($loginUrl)->with('error', 'Please login first');

        if (isset($expired)) {
            $redirect->withCookie($expired);
        }

        return $redirect;
    }

    /**
     * Muat preferensi user dari DB ke session sekali per session (bila belum ada).
     * Ini menjaga tema/warna/dll tetap konsisten setelah login baru atau restore
     * remember-me — bukan hanya setelah membuka halaman Settings.
     *
     * Dibungkus try/catch: kegagalan load preferensi TIDAK boleh men-crash request;
     * cukup lewati dan biarkan view memakai default-nya.
     */
    private function hydratePreferences(Request $request): void
    {
        if (session()->has('user_preferences')) {
            return;
        }

        try {
            $user = session('user');
            if (!$user || empty($user['id'])) {
                return;
            }

            $column = ($user['type'] ?? 'employee') === 'customer' ? 'customer_id' : 'employee_id';

            $raw = DB::table('auth_users')->where($column, $user['id'])->value('preferences');
            if (!$raw) {
                return;
            }

            $prefs = is_array($raw) ? $raw : json_decode($raw, true);
            if (is_array($prefs) && $prefs) {
                session(['user_preferences' => $prefs]);
            }
        } catch (Throwable $e) {
            Log::warning('CheckAuthToken: hydrate preferences gagal', [
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Coba restore session dari remember-me cookie.
     * Return true jika berhasil, false jika token tidak valid / user tidak aktif.
     *
     * PENTING: seluruh proses dibungkus try/catch. Kegagalan restore (mis. query
     * error karena skema DB berbeda) TIDAK boleh melempar 500 — cukup anggap
     * cookie tidak valid dan jatuh ke jalur "silakan login".
     */
    private function tryRestoreSession(Request $request, string $rawToken): bool
    {
        try {
            // Hash cookie value dan cari di DB
            $hashed  = hash('sha256', $rawToken);
            $authUser = DB::table('auth_users')
                ->where('remember_token', $hashed)
                ->where('is_active', true)
                ->first();

            if (!$authUser || empty($authUser->employee_id)) {
                return false;
            }

            // 2FA-enabled accounts never get restored via this cookie — a
            // stolen/replayed remember-me cookie must not grant a full
            // session for up to REMEMBER_DAYS with zero second-factor check.
            // (AuthController::finalizeEmployeeLogin() already refuses to
            // *issue* this cookie for a 2FA account in the first place; this
            // is the defense-in-depth half — it also protects a cookie that
            // was issued before 2FA was enabled on the account.)
            if (TwoFactorAuthService::isEnabled($authUser)) {
                return false;
            }

            // Bangun ulang session data employee
            $sessionData = AuthController::buildEmployeeSessionData($authUser->employee_id);

            if (!$sessionData) {
                return false;
            }

            // Update last_login_at
            DB::table('auth_users')
                ->where('id', $authUser->id)
                ->update(['last_login_at' => now()]);

            // Regenerate session (keamanan) & isi ulang
            $request->session()->regenerate();
            $request->session()->put('auth_token', $sessionData['token']);
            $request->session()->put('user', $sessionData['userData']);
            $request->session()->save();

            return true;
        } catch (Throwable $e) {
            // Restore gagal — jangan sampai men-crash request. Log lalu perlakukan
            // sebagai cookie tidak valid.
            Log::warning('CheckAuthToken: remember-me restore gagal', [
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }
}
